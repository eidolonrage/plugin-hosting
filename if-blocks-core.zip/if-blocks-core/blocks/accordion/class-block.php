<?php

/*
 * Accordion.
 */


namespace ibfblocks;

if (!defined('ABSPATH')) { exit; }

class IbfAccordion {

  function __construct() {
    add_action('init', array($this, 'registerBlock'));
    add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
  }

  public function enqueue_scripts() {
    // wp_enqueue_style('accordion-block', plugin_dir_url(__FILE__) . 'assets/css/block.css');
    wp_register_script('if-accordion-init', plugin_dir_url(__FILE__) . 'assets/js/if-accordion-init.js', array('jquery', 'if-accordion'), time());
  }

  public function registerBlock() {
	  if (!function_exists('register_block_type')) { return; }

	  if (file_exists(__DIR__ . '/block.json')) {
		  register_block_type(__DIR__ . '/block.json');
	  }
  }
}

new IbfAccordion();
