<?php

/*
 * Accordion.
 */

namespace ibfblocks;

if (!defined('ABSPATH')) { exit; }

$id = 'ibf-accordion-' . $block['id'];
$class_name = 'ibf-accordion';

if(!empty($block['className'])) {
  $class_name .= ' ' . $block['className'];
}

?>

<div class="<?php echo $class_name; ?>">
  <ul class="accordionjs" id="<?php echo $id; ?>">

<?php
while (have_rows('accordion')) {
  the_row();
  // Load values and assign defaults.
  $question = get_sub_field('question') ?: null;
  $answer = get_sub_field('answer') ?: null;

  if ($answer != null) {
?>
    <li>
      <div class="accordion-upper">
        <svg class="accordion_icon expand_icon" width="24" height="24" xmlns="http://www.w3.org/2000/svg">
          <line x1="11" y1="21" x2="11" y2="1" stroke="black" stroke-width="4" />
          <line x1="1" y1="11" x2="21" y2="11" stroke="black" stroke-width="4" />
        </svg>
        <svg class="accordion_icon contract_icon" width="24" height="24" xmlns="http://www.w3.org/2000/svg">
          <line x1="2" y1="2" x2="20" y2="20" stroke="black" stroke-width="4" />
          <line x1="2" y1="20" x2="20" y2="2" stroke="black" stroke-width="4" />
        </svg>
        <p class="acc-upper-text"><?php echo esc_attr($question); ?></p>
      </div>
      <div class="accordion-lower">
        <div class="acc-lower-spacer"><div></div></div>
        <div class="acc-lower-text"><?php echo $answer; ?></div>
      </div>
    </li>
<?php } else if ($question != null) { ?>
    <li>
      <div class="accordion-upper checkmark-item">
        <svg class="accordion_icon checkmark_icon" width="24" height="24" xmlns="http://www.w3.org/2000/svg">
          <line x1="2" y1="12" x2="11" y2="19" stroke="black" stroke-width="4" />
          <line x1="9" y1="20" x2="20" y2="2"  stroke="black" stroke-width="4" />
        </svg>
        <p class="acc-upper-text"><?php echo esc_attr($question); ?></p>
      </div>
    </li>
  <?php
  }
}
?>
  </ul>
</div>

<style>

.ibf-accordion {
  width: 100%;
}

ul.accordionjs {
  list-style-type: none;
}
.accordionjs {
  position: relative;
  margin: 0;
  padding: 0;
  list-style: none;
  margin-top: 10px;
  margin-bottom: 20px;
}
.ibf-accordion .accordionjs li {
  margin-left: 30px;
  margin-top: 15px;
  margin-bottom: 15px;
  padding: 0;
}
.accordionjs .acc_section {
  position: relative;
  z-index: 10;
  margin-top: -1px;
  overflow: hidden;
  border-radius: 3px;
}
.accordionjs .acc_section .accordion-upper.acc_head {
  position: relative;
  padding: 22px 4%;
  display: flex;
  flex-wrap: nowrap;
  font-weight: normal;
  cursor: pointer;
}

.accordionjs .acc_section .accordion-lower.acc_content {
  display: flex;
  flex-wrap: nowrap;
  padding: 10px 4%;
}

.accordionjs .acc_section .accordion-upper.checkmark-item {
  cursor: default;
  pointer-events: none;
}
.accordionjs .acc_section > .acc_head svg.accordion_icon {
  margin: auto 0;
  min-width: 32px;
  width: 50px;
}
.accordionjs .acc_section > .acc_head svg.contract_icon {
  display:  none;
}
.accordionjs .acc_section .acc_head h3 {
  line-height: 1;
  margin: 5px 0;
}
.accordionjs .acc_section .acc_content {
  padding: 10px;
}
.accordionjs li.acc_section.acc_active {
  outline: none;
}
.accordionjs .acc_section.acc_active > .acc_content {
  /* display: block; */
}
.accordionjs .acc_section.acc_active > .acc_head svg {
  /* flex-basis: 5%; */
}
.accordionjs .acc_section.acc_active > .acc_head svg.expand_icon{
  display:  none;
}
.accordionjs .acc_section.acc_active > .acc_head svg.contract_icon{
  display: block;
}
.accordionjs p.acc-upper-text {
  /* margin-left: 20px; */
  margin-block-start: 0;
  margin-block-end: 0;
  flex-basis: 95%;
}

div.ibf-accordion ul.accordionjs li div.acc-lower-spacer {
  /* flex-basis: 5%; */
  width: 50px;
}
div.ibf-accordion ul.accordionjs li div.acc-lower-spacer div {
  min-width: 32px;
  height: auto;
}
div.ibf-accordion ul.accordionjs li div.acc-lower-text {
/*  margin-left: 15px; */
  flex-basis: 95%;
}

@media screen and (max-width: 1200px) {
  .ibf-accordion ul.accordionjs li.acc_section {
    padding: 0 3%;
  }
}
</style>
<?php
if( ! wp_script_is( 'if-accordion' ) ) {
	wp_enqueue_script( 'if-accordion' );
}
if(!is_admin()) {
  wp_enqueue_script('if-accordion-init');
}
