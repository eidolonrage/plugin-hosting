<?php

/*
 * Facet Cards
 */

namespace ibfblocks;

if (!defined('ABSPATH')) { exit; }

if ( class_exists( 'FacetWP' ) && ! class_exists( __NAMESPACE__ . '\IbfFacetCards') ) {

	class IbfFacetCards {

		function __construct() {

			add_action( 'init', array( $this, 'register_block' ) );
		}

		public function register_block() {
			if ( file_exists(__DIR__ . '/block.json' ) ) {
				register_block_type( __DIR__ . '/block.json' );
			}
		}
	}
	new IbfFacetCards();
}
