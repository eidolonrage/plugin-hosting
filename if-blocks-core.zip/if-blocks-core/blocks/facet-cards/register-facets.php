<?php

class FacetCards {
	/**
	 * Autoload method
	 *
	 * @return void
	 */
	public function __construct() {
		add_filter( 'facetwp_facets', array( $this, 'facet_cards_register_facets' ) );
	}

	/**
	 * Register Taxonomies as custom facets
	 * @param $facets
	 *
	 * @return array
	 */
	public function facet_cards_register_facets( $facets ) {
		$taxonomies = $this->get_tax_facets();

		foreach( $taxonomies as $taxonomy) {
			$tax = get_taxonomy( $taxonomy );
			$name = $this->render_facets( $taxonomy );
			$facets[] = [
				// settings for this facet
				'label' => $tax->labels->name,
				'name' => $name,
				'type' => 'dropdown',
				'source' => 'tax/' . $taxonomy,
				'parent_term' => '',
				'hierarchical' => 'no',
				'orderby' => 'count',
				'count' => '20',
				'show_expanded' => 'no',
				'ghosts' => 'no',
				'preserve_ghosts' => 'no',
				'operator' => 'and',
				'soft_limit' => '5'
			];
		}

		/*
		 * Register Load More
		 * */
		$facets[] = [
			// settings for this facet
			'label' => 'Load More',
			'name' => 'load_more',
			'type' => 'pager',
			'pager_type' => 'load_more',
			'load_more_text' => __( 'Load More', 'poycor' ),
			'loading_text' => __( 'Loading...', 'poycor' ),
		];
		return $facets;
	}

	/**
	 * @param $taxonomy_name
	 *
	 * @return string
	 */
	public function render_facets( $taxonomy_name ) {
		$taxonomy_name = 'if_' . str_replace( '-', '_', $taxonomy_name );
		return $taxonomy_name;
	}

	public function get_tax_facets() {
		$tax_facets = array();

		$args = array(
			'_builtin' => false
		);
		$taxonomies = get_taxonomies( $args );
		foreach( $taxonomies as $taxonomy) {
			$name = $this->render_facets( $taxonomy );
			$tax_facets[$name] = $taxonomy;
		}

		return $tax_facets;
	}

}

$GLOBALS['FacetCards'] = new FacetCards();