<?php

/**
 * Facet Cards Template
 */
global $FacetCards;
$facet_card_results = array();
$tax_facets = $FacetCards->get_tax_facets();
$featured_item_filter = array();
$post_ids = array();
$excluded_stone_ids = array();
$current_post_id = get_queried_object_id();
$card_count = 0;

$posts_per_page = get_field( 'facet_cards_to_show' );
$filters = get_field( 'facet_cards_filters' );
$facet_cards_filters = get_field( 'facet_cards_filters' );
$show_pagination = get_field( 'show_pagination' );
$facet_enable_filters = get_field( 'facet_enable_filters' );
$content_to_show = get_field( 'content_to_show' );
$facet_enable_view_all = get_field( 'facet_enable_view_all' );
$facet_enable_application_exclusion = get_field( 'facet_enable_application_exclusion' );
$facet_enable_pre_filter = get_field( 'facet_enable_pre_filter' );
$facet_pre_filter_taxonomy = get_field( 'facet_pre_filter_taxonomy' );
$featured_post_ids = get_field( 'featured_post_ids', $current_post_id );
$taxonomies = array();
$featured_item_enabled = false;
if( $facet_enable_application_exclusion && ! empty( $featured_post_ids ) ) {
	$featured_item_enabled = true;
	$featured_item_limit = $posts_per_page;
	$posts_per_page = -1;
}

$lang = 'en';
if (isset($_COOKIE['wp-wpml_current_language'])) {
  if ($_COOKIE['wp-wpml_current_language'] == 'fr-ca') {
    $lang = 'fr-ca';
  } elseif ($_COOKIE['wp-wpml_current_language'] == 'fr') {
    $lang = 'fr';
  }
}

if( $facet_enable_application_exclusion ) {
	$application_terms = get_the_terms( $current_post_id, 'application-tax' );
	if( ! empty( $application_terms ) ) {
		foreach( $application_terms as $term ) {
			$application_ids = get_field( 'which_applications_page', 'application-tax_' . $term->term_id );
			if( ! empty( $application_ids ) ) {
				foreach( $application_ids as $application_id ) {
					$post_ids[] = $application_id;
				}
			}
		}
	}

	if( ! empty( $post_ids ) ){
		foreach( $post_ids as $application_id ) {
			$excluded_stones = get_field( 'excluded_stones', $application_id );
			if( ! empty( $excluded_stones ) ) {
				foreach( $excluded_stones as $excluded_stone_id ) {
					$excluded_stone_ids[] = $excluded_stone_id;
				}
			}
		}
	}
}

// NATHAN: added a function to translate taxonomy labels for Polycor.com
if(!function_exists('translate_filter_labels')) {
  function translate_filter_labels($label) {
    $translation_array = [
      'Category' => 'Catégorie',
      'Tag' => '',
      'Stone Tag' => 'Produit de Pierre',
      'Products Tags (Mirror)' => 'Type de produit',
      'Application Tags (Mirror)' => 'Applications',
      'Resource Type' => 'Type de ressource',
      'Stone Colors' => 'Stone Colors',
      'Stone Materials' => 'Matériau de Pierre',
      'Site' => 'Site',
      'Stone Patterns' => '',
      'Project Tag' => 'Type de projet',
      'Project Categories' => 'Catégories de projet',
      'Quarries' => 'Carrières',
      'Store Category' => ''
    ];

    if(key_exists($label, $translation_array)) {
      return $translation_array[$label];
    }

    return $label;
  }
}
?>

<?php if( $facet_enable_filters ){ ?>
<div class="facet-cards-filters">
    <?php if( ! empty( $filters ) ) {
        foreach( $filters as $filter ) {
	        $tax = get_taxonomy( $filter['taxonomies'] );
	        $taxonomy_name = $filter['taxonomies'];
	        $taxonomy_name = $FacetCards->render_facets( $taxonomy_name );
	        $label = ( ! empty( $filter['filter_label'] ) ? $filter['filter_label'] : $tax->labels->name );

	        if( isset( $_GET['_' . $taxonomy_name] ) ) {
		        $featured_item_filter[$filter['taxonomies']] = $_GET['_' . $taxonomy_name];
	        }
            ?>
                <div class="facet-cards-filter facet-card-filter-<?php echo $taxonomy_name; ?>">
                    <h4 class="facet-card-filter-label"><?php echo translate_filter_labels($label); ?></h4>
			        <?php echo facetwp_display( 'facet', $taxonomy_name ); ?>
                </div>
        <?php
        }
		?>
	    <div class="facet-cards-filter">
		    <button onclick="FWP.refresh()"><?php ($lang == 'fr' || $lang == 'fr-ca') ? esc_html_e( 'Recherchez', 'if-blocks' ) : esc_html_e( 'Search', 'if-blocks' ); ?></button>
	    </div>
	<?php } ?>
</div>
<?php } ?>
<div class="facetwp-template facet-cards-wrapper if-blocks-stonefinder-listing grid">

	<?php
	/**
	 * Show the Featured Items
	 */
	if( $featured_item_enabled ) {
		//$excluded_stone_ids = array_merge( $excluded_stone_ids, $featured_post_ids );
		$featured_post_ids_args = array(
			'post_type'      => array( $content_to_show ),
			'posts_per_page' => -1,
			'post__in'       => $featured_post_ids,
			'orderby'        => 'post__in',
			'order'          => 'ASC',
			'post_status'    => 'publish',
		);
		if( ! empty( $featured_item_filter ) ) {
			$query_tax_filter = array( 'relation' => 'AND' );
			foreach( $featured_item_filter as $taxonomy => $slug ) {
				$query_tax_filter[] = array(
					'taxonomy' => $taxonomy,
					'field'    => 'slug',
					'terms'    => array( $slug ),
				);
			}
			$featured_post_ids_args['tax_query'] = $query_tax_filter;
		}
		$featured_post_ids_query = new WP_Query( $featured_post_ids_args );
		if ( $featured_post_ids_query->have_posts() ) : ?>
			<?php while ( $featured_post_ids_query->have_posts() ) : $featured_post_ids_query->the_post();
				$post_id        = get_the_ID();
				$facet_card_results[] = $post_id;
				$featured_image = get_the_post_thumbnail_url( $post_id, 'large' );
				$background     = ( $featured_image ? "background: url('{$featured_image}') no-repeat center; background-size: 150%;" : 'background-image: linear-gradient(359.83deg, rgba(0,0,0,0.7)2.02%, rgba(0,0,0,0) 97.75%)' );
				?>
				<a href="<?php the_permalink(); ?>" class="stonefinder-card featured-item result-card-<?php echo count( $facet_card_results ); ?>">
					<div class="stonefinder-card__image" style="<?php echo $background; ?>; background-size: cover;">
					</div>
					<h4 class="stonefinder-card__title"><?php the_title(); ?></h4>
				</a>
			<?php endwhile; ?>
			<?php wp_reset_postdata(); ?>
		<?php endif;
	}
	?>

	<?php
	$facet_query_args = array(
		"post_type"      => array( $content_to_show ),
		"posts_per_page" => $posts_per_page,
		"post__not_in"   => $excluded_stone_ids,
		'post_status'    => 'publish',
		"facetwp"        => true,
	);

  if( $facet_enable_pre_filter ) {
    if( ! empty( $facet_pre_filter_taxonomy ) ) {
      foreach( $facet_pre_filter_taxonomy as $taxonomy ) {
        $terms = get_the_terms( $current_post_id, $taxonomy );
        if( ! empty( $terms ) ) {
          foreach( $terms as $term ) {
            $taxonomies[$term->taxonomy][] = $term->term_id;
          }
        }
      }
      $query_tax_filter = array( 'relation' => 'AND' );
      foreach( $taxonomies as $taxonomy => $terms ) {
        $query_tax_filter[] = array(
          'taxonomy' => $taxonomy,
          'field'    => 'term_id',
          'terms'    => $terms,
        );
      }
      $facet_query_args['tax_query'] = $query_tax_filter;
    }
  }

	$fc_query = new WP_Query( $facet_query_args );
	if ( $fc_query->have_posts() ) :
    $card_count = count($fc_query->get_posts());
    ?>
		<?php while ( $fc_query->have_posts() ) : $fc_query->the_post();
			$post_id        = get_the_ID();
			$facet_card_results[] = $post_id;
			$featured_image = get_the_post_thumbnail_url( $post_id, 'large' );
      $post_type = get_post_type($post_id);
      if($post_type == 'resources') {
        $background = ($featured_image ? "background: url('{$featured_image}') no-repeat center top/cover;" : 'background-image: linear-gradient(359.83deg, rgba(0,0,0,0.7)2.02%, rgba(0,0,0,0) 97.75%)');
      } else {
        $background = ($featured_image ? "background: url('{$featured_image}') no-repeat center top/150%;" : 'background-image: linear-gradient(359.83deg, rgba(0,0,0,0.7)2.02%, rgba(0,0,0,0) 97.75%)');
      }
        ?>
		<?php if( $featured_item_enabled ) { ?>
			<?php if( ! in_array( $post_id, $featured_post_ids ) ) { ?>
	            <a href="<?php the_permalink(); ?>" class="stonefinder-card result-card-<?php echo count( $facet_card_results ); ?>" style="<?php echo ( $featured_item_enabled && count( $facet_card_results ) > 5 ? 'display: none;' : '' ); ?>">
	                <div class="stonefinder-card__image" style="<?php echo $background; ?>; background-size: cover;">
	                </div>
	                <h4 class="stonefinder-card__title"><?php the_title(); ?></h4>
	            </a>
			<?php } ?>
		<?php } else {  ?>
			<a href="<?php the_permalink(); ?>" class="stonefinder-card result-card-<?php echo count( $facet_card_results ); ?>" style="<?php echo ( $featured_item_enabled && count( $facet_card_results ) > 5 ? 'display: none;' : '' ); ?>">
				<div class="stonefinder-card__image" style="<?php echo $background; ?>">
				</div>
				<h4 class="stonefinder-card__title"><?php the_title(); ?></h4>
			</a>
		<?php } ?>
		<?php endwhile; ?>
		<?php wp_reset_postdata(); ?>
	<?php else : ?>
		<p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
	<?php endif; ?>
</div>
<div class="wp-block-button aligncenter">
	<?php
	if( $show_pagination ) {
		echo facetwp_display( 'facet', 'load_more' );
	} ?>
	<?php
	if( $featured_item_enabled ) {
		?>
		<div class="facetwp-facet">
			<button id="facet-card-load-more" class="facet-card-loadmore"><?php ($lang == 'fr' || $lang == 'fr-ca') ? _e( 'En Voir Plus', 'if-blocks' ) : _e( 'Load More', 'if-blocks' ); ?></button>
		</div>
		<?php
	}
	?>
</div>
<script>
    (function( $ ) {
        var facet_pager = 1;
        var facet_paged = 1;
        document.addEventListener('facetwp-refresh', function() {
            facet_pager = 1;
            facet_paged = 1;
            jQuery('#facet-card-load-more').show();
        });
        jQuery('#facet-card-load-more').click(function( a ) {
            a.preventDefault();
            facet_pager = facet_pager + 1;
            facet_paged = facet_paged + 1;
            var facet_results = jQuery('div.if-blocks-stonefinder-listing a.stonefinder-card').length;
            var total_page = facet_results / 5;
            var facet_elements = 5 * facet_pager;
            jQuery('div.if-blocks-stonefinder-listing a:lt('+facet_elements+').stonefinder-card').show();
            if( facet_paged > total_page ) {
                jQuery('#facet-card-load-more').hide();
            }
        });
        document.addEventListener('facetwp-loaded', function() {
            FWP.auto_refresh = false;
        });
    })( jQuery );
</script>
<style>
  <?php if($card_count <= 4) { ?>
  .if-blocks-stonefinder-listing {
    justify-items: center;
  }
  .if-blocks-stonefinder-listing .stonefinder-card {
    max-width: 250px;
  }
  <?php }
   if($card_count == 2) { ?>
    .facetwp-template.if-blocks-stonefinder-listing.grid {
      grid-template-columns: repeat(4, minmax(200px, 1fr));
    }
    .if-blocks-stonefinder-listing .stonefinder-card:first-child {
      grid-column-start: 2;
    }
    .if-blocks-stonefinder-listing .stonefinder-card:last-child {
      grid-column-start: 3;
    }

    @media screen and (max-width: 940px) {
      .facetwp-template.if-blocks-stonefinder-listing.grid {
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      }
      .if-blocks-stonefinder-listing .stonefinder-card:first-child {
        grid-column-start: unset;
      }
      .if-blocks-stonefinder-listing .stonefinder-card:last-child {
        grid-column-start: unset;
      }
    }
  <?php } ?>
</style>
