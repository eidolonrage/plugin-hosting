<?php

/*
 * Linkable Image Block
 */

namespace ibfblocks;

if (!defined('ABSPATH')) { exit; }

if (!class_exists(__NAMESPACE__ . '\IbfLinkableImage')) {
  class IbfLinkableImage {
    function __construct() {
      add_action('init', array($this, 'registerBlock'));
    }

    public function registerBlock() {
	    if (!function_exists('register_block_type')) { return; }

	    if (file_exists(__DIR__ . '/block.json')) {
		    register_block_type(__DIR__ . '/block.json');
	    }
    }

    public function renderBlock($block) {
      require(__DIR__ . '/template.php');
    }
  }
  new IbfLinkableImage();
}
