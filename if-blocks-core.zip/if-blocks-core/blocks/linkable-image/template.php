<?php

/*
 * Linkable Image Block
 */

namespace ibfblocks;

if (!defined('ABSPATH')) { exit; }

$id = 'ibf-linkableimage-' . $block['id'];

$classes = [ 'ibf-linkableimage' ];
$bg_classes = ['bg-container'];
if ( ! empty( $block['className'] ) ) {
  $classes = array_merge( $classes, explode( ' ', $block['className'] ) );
}
if ( ! empty( $block['align'] ) ) {
  $classes[] = 'align' . $block['align'];
}
if ( ! empty( $block['backgroundColor'] ) ) {
  $bg_classes[] = 'has-background';
  $bg_classes[] = 'has-' . $block['backgroundColor'] . '-background-color';
}
if ( !empty( $block['gradient'])) {
  $bg_classes[] = 'has-background';
  $bg_classes[] = 'has-' . $block['gradient'] . '-gradient-background';
}
if ( ! empty( $block['textColor'] ) ) {
  $classes[] = 'has-text-color';
  $classes[] = 'has-' . $block['textColor'] . '-color';
}
if (get_field('background_color_overlay')) {
  $classes[] = 'bg-color-overlay';
}

$className = esc_attr( join( ' ', $classes ) );
$bgClassName = esc_attr( join( ' ', $bg_classes ) );

if(!get_field('background_image')): ?>
  <div class="no-bg-img-set">
    <p><strong>Please add a background image.</strong></p>
  </div>
<?php 
endif;
if(get_field('background_image')) { ?>
    <?php if(!get_field('link')) { ?>
      <div class="<?php echo $className; ?>" style="background-image: url(<?php the_field('background_image'); ?>);">
        <div class="<?php echo $bgClassName; ?>"></div>
        <div class="inner-blocks-fields">
          <InnerBlocks />
        </div>     
      </div>
    <?php } else { ?>
      <a class="<?php echo $className; ?> linkableimage-link" style="background-image: url(<?php the_field('background_image'); ?>);"
        <?php
        // only add href if not in block editor mode  
        if(!is_admin()) { 
          echo 'href="';
          the_field('link');
          echo '"'; 
        }
        ?>>
        <div class="<?php echo $bgClassName; ?>"></div>
        <div class="inner-blocks-fields">
          <InnerBlocks />
        </div>
      </a>
    <?php } ?>
<!--  </div> -->
<?php } ?>

<style>
.no-bg-img-set {
  display: block;
  width: 100%;
  height: 50%;
}

.ibf-linkableimage {
  display: block;
  position: relative;
  background-size: cover;
  transition: opacity 0.3s ease-in-out;
}

.inner-blocks-fields {
  position: relative;
}

.ibf-linkableimage.bg-color-overlay {
  z-index: 1;
  background-position: center;
}

.ibf-linkableimage.bg-color-overlay .bg-container {
  z-index: 2;
  opacity: 1;
}

.ibf-linkableimage.bg-color-overlay .inner-blocks-fields {
  z-index: 3;
}

.ibf-linkableimage .bg-container {
  transition: all 0.3s;
  opacity: 0;
}

.ibf-linkableimage .bg-container,
.ibf-linkableimage.bg-color-overlay .bg-container {
  background-size: cover;
  position: absolute;
  top: 0; 
  bottom: 0;
  width: 100%;
  height: auto;
}

.ibf-linkableimage .inner-blocks-fields p {
  margin: 0 auto;
  padding: 0;
}

a.ibf-linkableimage.linkableimage-link:hover > .bg-container,
.ibf-linkableimage:hover > .bg-container {
  opacity: 0.3;
}

a.ibf-linkableimage.linkableimage-link.bg-color-overlay:hover > .bg-container {
  opacity: 0.7;
}

</style>