<?php

/*
 * Categories Masonry Gallery
 */

namespace ibfblocks;

if (!defined('ABSPATH')) { exit; }

if ( class_exists( 'FacetWP' ) && ! class_exists( __NAMESPACE__ . '\IbfMasonryGallery') ) {

	class IbfMasonryGallery {

		function __construct() {
			add_action( 'init', array( $this, 'register_block' ) );
			add_action( 'wp_enqueue_scripts', array( $this, 'register_scripts' ) );
		}

		public function register_block() {
			if ( file_exists(__DIR__ . '/block.json' ) ) {
				register_block_type( __DIR__ . '/block.json' );
			}
		}

		/**
		 * Register Scripts for IF Blocks
		 * @return void
		 */
		public function register_scripts() {
			if ( ! wp_script_is( 'masonry-gallery-block-script' ) ) {
				wp_register_script( 'masonry-gallery-block-script', plugin_dir_url(__FILE__) . 'assets/js/masonry-gallery-js.js', array( 'jquery', 'desandro-masonry', 'flickity' ), filemtime(plugin_dir_path(__FILE__) . 'assets/js/masonry-gallery-js.js'), true );
			}
		}
	}
	new IbfMasonryGallery();
}