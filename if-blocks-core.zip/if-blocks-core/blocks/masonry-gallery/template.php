<?php

/**
 * Application Cards Template
 */
$post_ids = array();
$current_post_id = get_queried_object_id();
$which_images = get_field( 'ifb_which_images' );
$content_to_show = get_field( 'ifb_content_type' );
$images = array();
$gallery_images = get_field( 'ifb_images' );
$content_filters = get_field( 'ifb_content_filter' );
$limit = get_field( 'ifb_content_limit' );
$taxonomies = array();
if( $content_to_show ) {
    $filters = array();

    $query_args = array(
        "post_type"      => array( $content_to_show ),
        'posts_per_page' => $limit
    );

	if( $content_filters ) {
		foreach( $content_filters as $term ) {
			$taxonomies[$term->taxonomy][] = $term->term_id;
		}

		$query_tax_filter = array( 'relation' => 'AND' );
		foreach( $taxonomies as $taxonomy => $terms ) {
			$query_tax_filter[] = array(
				'taxonomy' => $taxonomy,
				'field'    => 'term_id',
				'terms'    => $terms,
			);
		}

		$query_args['tax_query'] = $query_tax_filter;
	}

    $query = new WP_Query( $query_args );
    if ( $query->have_posts() ) {
            $images = array();
            while ( $query->have_posts() ) {
            $query->the_post();
                $post_id        = get_the_ID();
                $image_id = get_post_thumbnail_id( $post_id );
                $images[] = $image_id;
    }
    wp_reset_postdata();
    }
} elseif($which_images == 'gallery') {
  $project_gallery = get_field('gallery', get_the_ID());

  if($project_gallery && !is_wp_error($project_gallery) && is_array($project_gallery)) {
    foreach ($project_gallery as $field) {
      $images[] = $field['id'];
    }
  }

} else {
	foreach( $gallery_images as $field ) {
		$images[] = $field['image'];
	}
}

// Get the count of values in the array
$count = count( $images );
// Initialize an empty array to hold the groups
$groups = array();
// Loop through the array, grouping the values in sets of 4
for ($i = 0; $i < $count; $i += 4) {
	$group = array_slice( $images, $i, 4);
	$groups[] = $group;
}

if( ! empty( $groups ) ) { ?>
<div class="if-blocks-masonry-gallery-wrapper flickity-loading">
    <?php foreach ( $groups as $group ) { ?>
        <div class="if-blocks-masonry-gallery-group">
	        <?php $i = 1; foreach ( $group as $image_id ) {
		        $image_size = 'large';
                if( $i == 3 || $i == 4 ) {
	                //$image_size = 'medium';
                }

                $image = wp_get_attachment_image( $image_id, 'large', '', array( 'class' => "attachment-{$image_size} size-{$image_size} masonry-item masonry-item-{$i}" ) );
		        echo $image;
                ?>
	        <?php $i++;} ?>
        </div>
    <?php } ?>
</div>
<?php }
wp_enqueue_script( 'desandro-masonry' );
wp_enqueue_script( 'flickity' );
wp_enqueue_style( 'flickity' );
wp_enqueue_script( 'masonry-gallery-block-script' );
?>
<script>

</script>
