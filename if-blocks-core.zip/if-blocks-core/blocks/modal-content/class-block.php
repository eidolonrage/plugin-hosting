<?php

/*
 * Modal Content
 */

namespace ibfblocks;

if (!defined('ABSPATH')) { exit; }

if (!class_exists(__NAMESPACE__ . '\IbfModalContent')) {
	class IbfModalContent {
		function __construct() {
			add_action( 'init', array( $this, 'registerBlock' ) );
		}

		function registerBlock() {
			if ( file_exists( __DIR__ . '/block.json' ) ) {
				register_block_type( __DIR__ . '/block.json' );
			}
		}
	}
	new IbfModalContent();
}