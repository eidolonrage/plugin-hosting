<?php

/**
 * Register Class for modal shortcode
 */
class IFModalContentShortcode {
	public function __construct() {
		add_shortcode( 'if_modal_content', array( $this, 'if_modal_content_shortcode' ) );
		add_shortcode( 'if-modal-content', array( $this, 'if_modal_content_shortcode' ) );

	}

	/**
	 * Shortcode to display the modal content anywhere
	 *
	 * @param $atts
	 *
	 * @return string POST Content of Selected CTA
	 */
	public function if_modal_content_shortcode( $atts, $content = '' ) {
		wp_enqueue_script( 'lity-modal' );
		wp_enqueue_style( 'lity-styles' );
		$random_id = 'ibf-modal-content-' . substr( md5 ( mt_rand()), 0, 4);
		$modal_id = ( ! empty( $atts['modal-id'] ) ? $atts['modal-id'] : $random_id );
		$trigger = ( ! empty( $atts['trigger'] ) ? $atts['trigger'] : 'click' );
		$trigger_class = ( ! empty( $atts['trigger-class'] ) ? $atts['trigger-class'] : 'if-modal-no-trigger-class' );
		$width = ( ! empty( $atts['width'] ) ? $atts['width'] . 'px' : 'auto' );
		$height = ( ! empty( $atts['height'] ) ? $atts['height']. 'px' : 'auto' );
		$trigger_delay = ( ! empty( $atts['delay'] ) ? $atts['delay'] : 5000 );
		$output = '';

		ob_start();
		?>
		<div id="<?php echo $modal_id; ?>" data-trigger="<?php echo $trigger; ?>" data-trigger-class="<?php echo $trigger_class; ?>"  class="if-modal-content-wrapper <?php echo $trigger_class; ?>-wrapper <?php echo ( ! is_admin() ? 'lity-hide' : '' ); ?>">
			<img decoding="async" data-lity-close="" class="close-modal ibf-news-card-modal-close" src="/wp-content/plugins/if-search-modal/assets/images/icon-site-close.svg">
			<div class="if-modal-content" style="background: #FFF; display: block;">
				<?php echo $content; ?>
			</div>
		</div>
		<style>
            /* Modal content styles */
            .if-modal-content-wrapper {
	            margin: 0 auto;
	            position: relative;
                background-color: #FFF;
                padding: 20px;
                border: 1px solid #888;
                min-width: <?php echo $width; ?>;
                min-height: <?php echo $height; ?>;
	            max-width: 1000px;
            }
            .close-modal {
                position: absolute;
                top: -18px;
                right: -18px;
                font-size: 20px;
                cursor: pointer;
                padding: 3px 12px;
            }
		</style>
		<?php if( ! is_admin() ): ?>
			<?php if( $trigger == 'click' ) { ?>
				<script>
					jQuery(document).ready(function() {
		                jQuery(document).on( 'click', '.<?php echo $trigger_class;?>', function(a) {
		                    a.preventDefault();
		                    lity('#<?php echo $modal_id; ?>');
		                });
					});
				</script>
			<?php } ?>

			<?php if( $trigger == 'pageload' ) { ?>
				<script>
	                jQuery(document).ready(function() {
	                    setTimeout( function () {
                            lity('#<?php echo $modal_id; ?>');
	                    }, <?php echo $trigger_delay; ?>);
	                });
				</script>
			<?php } ?>
		<?php endif; ?>
		<?php
		$output .= ob_get_contents();
		ob_end_clean();
		return $output;
	}

}

new IFModalContentShortcode();