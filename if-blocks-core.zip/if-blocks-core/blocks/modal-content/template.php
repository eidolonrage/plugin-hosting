<?php

$id = 'ibf-modal-content-' . $block['id'];
$trigger_type = get_field( '_modal_content_trigger_type' );
$trigger_class = get_field( '_modal_content_trigger_class' );
$trigger_delay = get_field( '_modal_content_trigger_delay' );
$trigger_delay = ( ! empty( $trigger_delay ) ? $trigger_delay * 1000 : 5000 );
$width = get_field( '_modal_content_modal_width' );
$height = get_field( '_modal_content_modal_height' );

if( is_admin() ) { ?>
	<InspectorControls>
		<h6 style="background: #DEDEDE; color: #AAA; padding: 6px;">Modal content <em>(this is visible on backend only)</em></h6>
	</InspectorControls>
<?php } ?>

<?php echo do_shortcode("[if-modal-content modal-id='{$id}' trigger='{$trigger_type}' delay='{$trigger_delay}' trigger-class='{$trigger_class}' width='{$width}' height='{$height}']<InnerBlocks />[/if-modal-content]"); ?>