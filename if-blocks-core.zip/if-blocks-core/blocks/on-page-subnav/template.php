<?php

/*
 * On-page Subnav Menu Block
 */

namespace ibfblocks;

if (!defined('ABSPATH')) { exit; }

// Create id attribute allowing for custom "anchor" value.
$id = 'ibf-on-page-subnav' . $block['id'];
if (!empty($block['anchor'])) {
  $id = $block['anchor'];
}

// Create class attribute allowing for custom "className" values.
if (!empty($block['className'])) {
  $classes[] = $block['className'];
}

$classes[] = 'on-page-subnav-menu';

$className = esc_attr(join(" ", $classes));

$current_page_link = get_the_permalink();

$query_string = ( ! empty( $_SERVER['QUERY_STRING'] ) ? $_SERVER['QUERY_STRING'] : '' );
$query_string = ( ! empty( $query_string ) ? substr( $query_string, ( strpos( $query_string, '=') ?: -1 ) + 1 ) : ''  );
$query_string = '#' . $query_string;

$webinar_query_string = ( ! empty( $_SERVER['QUERY_STRING'] ) ? $_SERVER['QUERY_STRING'] : '' );
$webinar_query_string = ( ! empty( $webinar_query_string ) ? substr( $webinar_query_string, ( strpos( $webinar_query_string, 'webinars_') ?: -1 ) + 9 ) : ''  );
$webinar_query_string = ( ! empty( $webinar_query_string ) ? explode( '=', $webinar_query_string ) : '' );
$webinar_query_string = ( isset( $webinar_query_string[0] ) ? '#' . $webinar_query_string[0] : '' );

if (have_rows('links')) {
  ?>
  <div id="<?php echo $id; ?>" class="subnav-menu-container <?php echo $className; ?>">
  <?php while (have_rows('links')) {
    the_row();
    // display as custom columns (no wp-block-column for this)
    $link = get_sub_field('link');
    $title_data = str_replace(" ","_", get_sub_field('link_title'));
    $active_class = '';

    if ( ( $link == $current_page_link ) || ( $query_string == $link )  /* || str_contains($current_page_link, $link) */) {
      $active_class = 'active';
    }

    // If Webinars
    if( $webinar_query_string == $link  ) {
	    $active_class = 'active';
    }
    ?>

    <div class="subnav-menu-item">
      <a onclick="clickSingleA(this)" onauxclick="clickSingleA(this)" href="<?php the_sub_field('link'); ?>" class="subnav-menu-link <?php echo $active_class; ?>" data-<?php echo $title_data; ?>><?php the_sub_field('link_title'); ?>
      <?php
      if (!str_starts_with($link, '#')) { ?>
        <svg class="subnav-external-link-icon" width="18" height="17" viewBox="0 0 18 17" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M0.75 0.25V16.75H17.25V0.25H0.75ZM2.25 1.75H15.75V15.25H2.25V1.75ZM6.75 4V5.5H10.9219L3.96094 12.4609L5.03906 13.5391L12 6.57812V10.75H13.5V4H6.75Z" fill="#505050"/>
        </svg>
      <?php } ?>
      </a>
    </div>
  <?php } ?>
  </div>
<?php } ?>

<script>
function clickSingleA(a) {
  'use strict'

  if (!window.jQuery) {
    setTimeout('clickSingleA()', 100)
    return
  }

  var $ = jQuery

  $(document).ready(function() {
    let items = document.querySelectorAll('.subnav-menu-link.active')
    // console.log('in clickSingleA')
    if(items.length)
    {
      items[0].className = 'subnav-menu-link'
    }

    a.className = 'subnav-menu-link active'

  })
}
</script>

<style>
.subnav-menu-container {
  display: flex;
  flex-flow: row nowrap;
  justify-content: space-around;
  align-content: center;
  background-color: #FFFFFF;
}

.subnav-menu-container .subnav-menu-item {
  color: #505050;
}

.subnav-menu-container .subnav-menu-item a.subnav-menu-link {
  color: inherit;
  text-decoration: none;
  text-transform: uppercase;
  font-weight: 800;
  transition: all 0.1s;
  padding: 15px 10px;
}

.subnav-menu-container .subnav-menu-item a.subnav-menu-link:hover,
.subnav-menu-container .subnav-menu-item a.subnav-menu-link.active {
  color: #00539F;
  border-bottom: 6px solid #00539F;
}

.subnav-menu-container .subnav-menu-item a.subnav-menu-link:hover svg path,
.subnav-menu-container .subnav-menu-item a.subnav-menu-link.active svg path {
  fill: #00539F;
}

@media screen and (max-width: 1330px) {
  div.subnav-menu-container {
    flex-flow: row nowrap;
  }
}

@media screen and (max-width: 1200px) {
  div.subnav-menu-container {
    flex-flow: row wrap;
  }
}

@media screen and (max-width: 600px) {
  div.subnav-menu-container {
    padding-bottom: 5px;
  }
  div.subnav-menu-container div.subnav-menu-item {
    flex-basis: 50%;
    padding-top: 0;
  }
}
</style>

