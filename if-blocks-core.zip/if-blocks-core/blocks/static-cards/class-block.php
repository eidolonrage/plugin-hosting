<?php

/*
 * Subsite Content Test Block
 */

namespace ibfblocks;

if (!defined('ABSPATH')) { exit; }
if(!defined('IF_BLOCKS_PLUGIN_PATH')) { exit; }

if (!class_exists(__NAMESPACE__ . '\IbfStaticCardsBlock')) {
  class IbfStaticCardsBlock {
    function __construct() {
      add_action('init', array($this, 'registerBlock'));
      add_action('wp_enqueue_scripts', array($this, 'enqueueScripts'));
      add_action('admin_enqueue_scripts', array($this, 'enqueueScripts'));
    }

    function registerBlock() {
      if (!function_exists('register_block_type')) { return; }

	  if (file_exists(__DIR__ . '/block.json')) {
        register_block_type(__DIR__ . '/block.json');
      }
    }

    function enqueueScripts() {
	    if (!wp_script_is('slider-init-static-cards', 'registered')) {
		    wp_register_script('slider-init-static-cards',
			    plugin_dir_url(__FILE__) . 'assets/js/slider-init-static-cards.js',
			    array('jquery', 'flickity'),
			    filemtime(__DIR__ . '/assets/js/slider-init-static-cards.js'));
	    }
    }
  }
  new IbfStaticCardsBlock();
}
