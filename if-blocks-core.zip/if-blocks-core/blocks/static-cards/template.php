<?php

/*
 * Static Cards Block
 */

namespace ibfblocks;

if (!defined('ABSPATH')) { exit; }

$id = 'ibf-staticcards-' . $block['id'];
$className = '';
if (!empty($block['className'])) {
  $className = $block['className'];
}

$lang = 'en';
if (isset($_COOKIE['wp-wpml_current_language'])) {
  if ($_COOKIE['wp-wpml_current_language'] == 'fr-ca') {
    $lang = 'fr-ca';
  } elseif ($_COOKIE['wp-wpml_current_language'] == 'fr') {
    $lang = 'fr';
  }
}

$template = get_field('cards_template');
$images_dir = plugin_dir_url(__FILE__) . 'assets/img/';
$_if_static_cards_templates = get_option( '_if_static_cards_templates' );
$slider = get_field('display_as_slider');

$bg_img_choices = array();
// TODO populate $bg_img_choices from the bg images options field if they exist

if(have_rows('card_default_bg_image_choices', 'options')) {
  // TODO populate $bg_img_choices from options repeater field
  while (have_rows('card_default_bg_image_choices', 'options')) {
    the_row();
    // $bg_img_choices[] = get_sub_field('image');
  }
} else {
  $bg_img_choices = array(
    $images_dir . 'stc_cd_bg.jpg',
    $images_dir . 'stc_cd_bg2.jpg',
    $images_dir . 'stc_cd_bg3.jpg'
  );
}

// build cards information array based on what type of card layout is used
/*
array (
  array(
    'post_id'        =>
    'post_type'      =>
    'label'          =>
    'background'     =>
    'featured_image' =>
    'title'          =>
    'taxonomies'     =>
    'search_include' =>
    'search_exclude' =>
    'detail_text'    =>
    'icon'           =>
    'card_link'      =>
    'lang'           =>
   ),
);
*/

$cards_array = array();
$count = 0;
// populate $cards_array from the static_cards rows in the block
if (have_rows('static_cards')) {
  while (have_rows('static_cards')) {
    the_row();
    if ($count == count($bg_img_choices)) {
      $count = 0;
    }

    if (get_row_layout() == 'dynamic_info_card') {
      // do stuff based on tax term or post/page
      if (get_sub_field('item_type') == 'post_item') {
        $post_obj = get_sub_field('post_item');

        if ($post_obj) {
          $featured_image = get_the_post_thumbnail_url($post_obj, 'large');
          $post_id = $post_obj->ID;
          $post_type = get_post_type_object(get_post_type($post_id));

          // if featured image exists, use that, otherwise pick a random image out of the array of default options
          $background = ( $featured_image ? "background-image: url('{$featured_image}');" :
            "background-image: url('{$bg_img_choices[$count]}');" );

          if($lang == 'fr' || $lang == 'fr-ca') {
            $post_title = $post_obj->post_title;
          } else {
            //trim the title to 55 chars and append "..." if too long
            $post_title = wp_trim_words(get_the_title($post_id));
          }

          $cards_array[] = array(
            'post_id'        => $post_id,
            'post_type'      => $post_type->name,
            'label'          => $post_type->label,
            'background'     => $background,
            'featured_image' => $featured_image,
            'title'          => $post_title,
            'taxonomies'     => '',
            'search_include' => '',
            'search_exclude' => '',
            'icon'           => false,
            'card_link'      => false,
            'lang'           => $lang
          );
        }
      } else {

        $term_obj = get_sub_field('term_item');

        // print_r($term_obj);

        if($term_obj && !is_wp_error($term_obj) && is_object($term_obj) && term_exists($term_obj->term_id)) {
          $term_id_num = $term_obj->term_id;
          $taxonomy_name = $term_obj->taxonomy;
          $tax_obj = get_taxonomy($taxonomy_name);
          $tax_label = $tax_obj->label;
          $term_id_string = $taxonomy_name . '_' . $term_id_num;
          $title = $term_obj->name;
          $icon = get_field('icon', $term_id_string);
          $post_type = '';
          $post_type_name = '';
          $post_id = get_field('associated_post', $term_id_string);
          $tag_image = get_field('tag_image', $term_id_string);

          if($lang == 'en') {
            $link = get_site_url() . '/' . $term_obj->taxonomy . '/' . $term_obj->slug . '/';
          } elseif($lang == 'fr-ca') {
            $link = get_site_url() . '/' . 'fr-ca/' . $term_obj->taxonomy . '/' . $term_obj->slug . '/';
          } else {
            $link = get_site_url() . '/' . 'fr/' . $term_obj->taxonomy . '/' . $term_obj->slug . '/';
          }

//          \ibfblocks\includes\logit('in static cards, $link=', $link);
//          \ibfblocks\includes\logit('for term: ', $term_obj->name);

          if ($post_id) {
            $featured_image = get_the_post_thumbnail_url($post_id, 'if-dynamic-cards');
            $background = ($featured_image ? "background-image: url('{$featured_image}');" :
              "background-image: url('{$bg_img_choices[array_rand($bg_img_choices)]}');");
            $post_type = get_post_type_object(get_post_type($post_id));
            $post_type_name = $post_type->name;
            $label = $post_type->label;
          } elseif($tag_image) {
            $post_id = null;
            $featured_image = $tag_image['sizes']['large'];
            $background = "background-image: url('{$featured_image}');";
            $label = '';
          } else {
            $post_id = null;
            $featured_image = '';
            $background = "background-image: url('{$bg_img_choices[$count]}');";
            $label = '';
          }

          $cards_array[] = array(
            'post_id' => $post_id,
            'post_type' => $post_type_name,
            'label' => $label ?: $tax_label,
            'background' => $background,
            'featured_image' => $featured_image,
            'title' => wp_trim_words($title), //trim the title to 55 chars and append "..." if too long
            'taxonomies' => '',
            'search_include' => '',
            'search_exclude' => '',
            'icon' => $icon ?: false,
            'card_link' => $link ?: false,
            'lang' => $lang
          );
        }
      }
    } else {
      // this card is a Custom Info Card

      $title = wp_trim_words(get_sub_field('card_title')); //trim the title to 55 chars and append "..." if too long
      $label = get_sub_field('pill_label');
      $link = get_sub_field('card_link');
      $card_image = get_sub_field('background_image');
      $icon = get_sub_field('card_icon');

      if (!$card_image) {
        $featured_image = '';

        // if no card image is set, select a random background image from the available choices
        $background = "background-image: url('{$bg_img_choices[$count]}');";
      } else {
        $featured_image = $card_image;
        $background = "background-image: url('$card_image');";
      }

      $cards_array[] = array(
        'post_id'        => false,
        'post_type'      => false,
        'label'          => $label,
        'background'     => $background,
        'featured_image' => $featured_image,
        'title'          => $title,
        'taxonomies'     => '',
        'search_include' => '',
        'search_exclude' => '',
        'icon'           => $icon ?: false,
        'card_link'      => $link ?: false,
        'lang' => $lang
      );
    }
    $count++;
  }

  if($slider && count($cards_array) > 3) { ?>
    <div id="if-dynamic-cards-wrapper-<?php echo $id;?>" class='if-dynamic-cards-wrapper <?php echo esc_attr( $template ); ?> <?php echo 'if-dynamic-cards-slider'; ?> static-cards-wrapper <?php echo $className; ?>'>
      <div class="if-dynamic-cards-content-wrapper">
        <div class="if-dynamic-cards-content static-cards-with-slider">
  <?php } else { ?>
    <div id="if-dynamic-cards-wrapper-<?php echo $id;?>" class='if-dynamic-cards-wrapper <?php echo esc_attr( $template ); ?> <?php echo 'if-dynamic-cards-no-slider'; ?> static-cards-wrapper <?php echo $className; ?>'>
      <div class="if-dynamic-cards-content-wrapper">
        <div class="if-dynamic-cards-content static-cards-no-slider">
  <?php } ?>
<?php

  // randomize the order of cards_array if Randomize Card Order is set to true
  if (get_field('randomize_card_order')) {
    shuffle($cards_array);
  }

  // display each card in $cards_array based on the template selected by the user in the "cards_template" field
  foreach ($cards_array as $card) {

    if (isset($_if_static_cards_templates[ $template ])) {
      load_template(
        $_if_static_cards_templates[ $template ],
        false,
        $card
      );
    }
  } ?>
      </div>
    </div>
  </div>
<?php }

if (!wp_script_is('flickity')) {
  wp_enqueue_script( 'flickity' );
}
if (!wp_style_is('flickity')) {
  wp_enqueue_style('flickity' );
}
if (!wp_script_is('slider-init-static-cards')) {
  wp_enqueue_script('slider-init-static-cards' );
}
if(wp_style_is('if-dynamic-blocks-cta-frontend-styles', 'registered') && !wp_style_is('if-dynamic-blocks-cta-frontend-styles')) {
  wp_enqueue_style( 'if-dynamic-blocks-cta-frontend-styles' );
}

?>

<style>

</style>

