<?php
/**
 * Template Name: Static Cards (no pill)
 */

extract( $args );

$link = false;

if($post_id) {
  $link = get_the_permalink($post_id);
} elseif ($card_link) {
  $link = $card_link;
}

$read_more_text = 'Read More';

if(!empty($lang)) {
  if ($lang == 'fr' || $lang == 'fr-ca') {
    $read_more_text = 'En savoir plus';
  }
}

if ($link) {
?>
<div class="if-dynamic-card-wrapper if-dynamic-cards-wrapper-card-type-<?php echo esc_attr( $post_type ); ?>" data-post_type="<?php echo esc_attr( $post_type ); ?>">
    <a href="<?php echo $link; ?>" class="if-dynamic-card card-type-<?php echo esc_attr( $post_type ); ?>" data-post_type="<?php echo esc_attr( $post_type ); ?>" style="<?php echo esc_attr( $background ); ?>">
        <div class="if-dynamic-card-header"><span class="if-dynamic-card-type"></span></div>
        <div class="if-dynamic-card-content">
            <span class="if-dynamic-card-type"></span>
            <h4 class="if-dynamic-card-title"><?php echo $title; ?></h4>
            <span class="if-dynamic-card-more"><?php esc_html_e( $read_more_text, 'if-dynamic-cta' ); ?></span>
        </div>
    </a>
</div>
<?php } else { ?>
  <div class="if-dynamic-card-wrapper if-dynamic-cards-wrapper-card-type-<?php echo esc_attr( $post_type ); ?>" data-post_type="<?php echo esc_attr( $post_type ); ?>">
    <div class="if-dynamic-card card-type-<?php echo esc_attr( $post_type ); ?>" data-post_type="<?php echo esc_attr( $post_type ); ?>" style="<?php echo esc_attr( $background ); ?>">
      <div class="if-dynamic-card-header"><span class="if-dynamic-card-type"></span></div>
      <div class="if-dynamic-card-content">
        <span class="if-dynamic-card-type"></span>
        <h4 class="if-dynamic-card-title"><?php echo $title; ?></h4>
      </div>
    </div>
  </div>
<?php } ?>
