<?php
/**
 * Template Name: Static Cards: Portfolio
 */

extract( $args );

$link = false;

if($post_id) {
  $link = get_the_permalink($post_id);
} elseif ($card_link) {
  $link = $card_link;
}

if ($link) {
?>
<div class="if-dynamic-card-wrapper if-dynamic-cards-wrapper-card-type-<?php echo esc_attr( $post_type ); ?>" data-post_type="<?php echo esc_attr( $post_type ); ?>">
    <a href="<?php echo $link; ?>" class="if-dynamic-card card-type-<?php echo esc_attr( $post_type ); ?>" data-post_type="<?php echo esc_attr( $post_type ); ?>" style="<?php echo esc_attr( $background ); ?>">
        <div class="if-dynamic-card-content">
            <h4 class="if-dynamic-card-title"><?php echo $title; ?></h4>
        </div>
    </a>
</div>
<?php } else { ?>
  <div class="if-dynamic-card-wrapper if-dynamic-cards-wrapper-card-type-<?php echo esc_attr( $post_type ); ?>" data-post_type="<?php echo esc_attr( $post_type ); ?>">
    <div class="if-dynamic-card card-type-<?php echo esc_attr( $post_type ); ?>" data-post_type="<?php echo esc_attr( $post_type ); ?>" style="<?php echo esc_attr( $background ); ?>">
      <div class="if-dynamic-card-content">
        <h4 class="if-dynamic-card-title"><?php echo $title; ?></h4>
      </div>
    </div>
  </div>
<?php } ?>
