<?php
/**
 * Template Name: Static Cards: All Data
 */

extract( $args );

/* Possible args:
$card = array(
       // DATA              EXISTS? \\
        'post_id'        -- sometimes int
        'post_type'      -- sometimes string
        'label'          -- sometimes string
        'background'     -- always CSS "background: url(URL);" string
        'featured_image' -- sometimes URL string
        'title'          -- always string
        'taxonomies'     -- never from static cards block
        'search_include' -- never from static cards block
        'search_exclude' -- never from static cards block
        'icon'           -- sometimes URL string
        'card_link'      -- sometimes URL string
      );
*/
$link = false;

if($post_id) {
$link = get_the_permalink($post_id);
} elseif ($card_link) {
$link = $card_link;
}

$read_more_text = 'Read More';

if(!empty($lang)) {
  if ($lang == 'fr' || $lang == 'fr-ca') {
    $read_more_text = 'En savoir plus';
  }
}

if ($link) { ?>
<div class="if-dynamic-card-wrapper">
  <a href="<?php echo $link; ?>" class="if-dynamic-card" style="<?php echo esc_attr( $background ); ?>">
    <div class="if-dynamic-card-header">
		<?php if( $label ) { ?>
      <span class="if-dynamic-card-type"><?php echo esc_attr( $label ); ?></span>
		<?php }
    if ($icon) { ?>
      <img src="<?php echo $icon; ?>">
    <?php } ?>
    </div>
    <div class="if-dynamic-card-content">
        <h4 class="if-dynamic-card-title"><?php echo $title; ?></h4>
        <span class="if-dynamic-card-more"><?php esc_html_e( $read_more_text, 'if-dynamic-cta' ); ?></span>
    </div>
  </a>
</div>
<?php } else { ?>
<div class="if-dynamic-card-wrapper">
  <div class="if-dynamic-card" style="<?php echo esc_attr( $background ); ?>">
    <div class="if-dynamic-card-header">
      <?php if( $label ) { ?>
        <span class="if-dynamic-card-type"><?php echo esc_attr( $label ); ?></span>
      <?php }
      if ($icon) { ?>
        <img src="<?php echo $icon; ?>">
      <?php } ?>
    </div>
    <div class="if-dynamic-card-content">
      <h4 class="if-dynamic-card-title"><?php echo $title; ?></h4>
    </div>
  </div>
</div>
<?php } ?>
