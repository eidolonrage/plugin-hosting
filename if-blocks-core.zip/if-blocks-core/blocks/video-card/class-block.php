<?php

/*
 * Video Card
 */

namespace ibfblocks;

if (!defined('ABSPATH')) { exit; }

class IbfVideoCard {
  function __construct() {
    // Assets loaded in acf_register_block_type below
    add_action('acf/init', array($this, 'registerBlock'));
	add_action('wp_enqueue_scripts', array($this, 'enqueueScripts'));
  }

  public function enqueueScripts() {
    if (!wp_style_is('if-video-card')) {
      wp_enqueue_style('if-video-card', plugin_dir_url(__FILE__) . 'assets/css/block.css', array(),
        filemtime(__DIR__ . '/assets/css/block.css'));
    }

    wp_register_script('init-inline-youtube-embed', plugin_dir_url(__FILE__) . 'assets/js/init-inline-youtube-embed.js', array(), time());
    wp_register_script('init-inline-vimeo-embed', plugin_dir_url(__FILE__) . 'assets/js/init-inline-vimeo-embed.js', array(), time());
  }

  public function registerBlock() {
	  if (!function_exists('register_block_type')) { return; }

	  if (file_exists(__DIR__ . '/block.json')) {
		  register_block_type(__DIR__ . '/block.json');
	  }
  }
}

new IbfVideoCard();
