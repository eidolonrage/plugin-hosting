<?php

/*
 * Video Card Block Template
 */

namespace ibfblocks;

if (!defined('ABSPATH')) { exit; }

if (!function_exists('ibfblocks\logat')) {
  // Log data (for debugging)
  function logat() {
    $args = func_get_args();
    if (empty($args)) { return; }
    $stuffToLog = '';
    foreach ($args as $arg) {
      if (!is_string($arg)) {
        $arg = print_r($arg, true);
      }
      $stuffToLog .= $arg . ' ';
    }
    $f = fopen(__DIR__ . '/log.txt', 'a+');
    fwrite($f, $stuffToLog . "\n");
    fclose($f);
  }
}

if (!function_exists('ibfblocks\getCurrentURL')) {
  function getCurrentURL()
  {
    $currentURL = (@$_SERVER["HTTPS"] == "on") ? "https://" : "http://";
    $currentURL .= $_SERVER["SERVER_NAME"];

    if($_SERVER["SERVER_PORT"] != "80" && $_SERVER["SERVER_PORT"] != "443")
    {
      $currentURL .= ":".$_SERVER["SERVER_PORT"];
    }

    $currentURL .= $_SERVER["REQUEST_URI"];
    return $currentURL;
  }
}

if (!function_exists('ibfblocks\getHTTPResponseStatusCode')) {
  function getHTTPResponseStatusCode($url) {
    $status = null;

    $headers = @get_headers($url, 1);
    if (is_array($headers)) {
      $status = substr($headers[0], 9);
    }

    return $status;
  }
}
$vimeo_embed_url = '';

if(!function_exists('ibfblocks\extract_vimeo_embed_url')) {
  function extract_vimeo_embed_url($string) {
    if(str_contains($string, 'vimeo')) {
      /*
      if(str_contains($string, '&')) {
        logat('new string contains &, position of & = ', strpos($string, '&'));
      }
      */
      $new_string = substr(
        $string,
        strpos($string, '"') + 1,
        strpos($string, '&') - (strpos($string, '"') + 1)
      );
      // logat('in extract_vimeo_embed_url, new string =', $new_string);
      if($new_string && str_contains($new_string, 'https')) {
        return $new_string;
      } else {
        return false;
      }
    }
    return false;
  }
}

if (!function_exists('ibfblocks\if_get_vimeo_thumb')) {
  // Returns thumbnail if private video on Vimeo
  function if_get_vimeo_thumb($link) {
    $referer = getCurrentURL();
    if (!$referer) { return ''; }
    $vimeo_url = 'https://vimeo.com/api/oembed.json?url=' . urlencode($link);
    // logat('in if_get_vimeo_thumb, $link =', $link);
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $vimeo_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $headers = array(
      'Referer: ' . $referer
    );
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    $response = curl_exec($ch);
    $obj = @json_decode($response);
    if (!$obj || !property_exists($obj, 'thumbnail_url')) {
      return '';
    } else {
      return $obj;
    }
  }
}
// Create id attribute allowing for custom "anchor" value.
$id = 'video-card-' . $block['id'];
if (!empty($block['anchor'])) {
  $id = $block['anchor'];
}

// Create class attribute allowing for custom "className" and "align" values.
$class_name = 'ibf-video-card';
if (!empty($block['className'])) {
  $class_name .= ' ' . $block['className'];
}

// Load values and assign defaults.
$img = get_field('image') ?: '';
$label = get_field('label') ?: '';
$img_layout = get_field('image_layout') ?: 'center center';
$img_dimensions = get_field('image_dimensions') ?: '';
$link = get_field('link');
$lity_popup_text = 'data-lity';
$dots_background_img = plugin_dir_url(__FILE__) . 'assets/img/dots_bg_2.png';
$svg_play_icon = get_field('play_icon', 'option');
$svg_code = get_field('svg_code', 'option');
$disabled = get_field('disabled');
$video_id = '';
$is_vimeo = false;

// Try for a Vimeo or YouTube background image, if available
if (!$img && strpos($link, 'vimeo') !== false) {
  $object = if_get_vimeo_thumb($link);
    // logat('in if_get_vimeo_thumb, $obj =', $obj);
  $vimeo_embed_url = extract_vimeo_embed_url($object->html);
  // logat('after extraction, $vimeo_embed_url =', $vimeo_embed_url);
  $thumb_url = substr_replace($object->thumbnail_url, '_1280', strpos($object->thumbnail_url, "_"));
  // print_r($obj->thumbnail_url);
  // print_r($nu_url);
  $response_code = getHTTPResponseStatusCode($thumb_url);
  if ($response_code != "200 OK") {
    $img = $object->thumbnail_url ?: plugin_dir_url(__FILE__) . 'assets/img/vimeo.jpg';
  } else {
    $img = $thumb_url ?: plugin_dir_url(__FILE__) . 'assets/img/vimeo.jpg';
  }

  $is_vimeo = true;
} elseif (!$img && strpos($link, 'youtu') !== false) {
  // Get youtube background image (if it exists)
  preg_match("#(?<=v=)[a-zA-Z0-9-]+(?=&)|(?<=v\/)[^&\n]+(?=\?)|(?<=v=)[^&\n]+|(?<=youtu.be/)[^&\n]+#", $link, $matches);
  if ($matches) {
    $video_id = $matches[0];
    // \ibfblocks\includes\logit('youtube video id =', $video_id);
    $img = 'https://img.youtube.com/vi/' . $matches[0] . '/hqdefault.jpg';
  }
  // echo '<script src="http://www.youtube.com/iframe_api"></script>';
}

if ($img_dimensions) {
?>
  <script>
  (function() {
    'use strict'

    function init() {
      if (!window.jQuery) {
        setTimeout(init, 100)
        return;
      }

    const $ = jQuery
      $(function() {
        const resize = () => {
          const h = $('a[rel=<?php echo esc_attr($id); ?>]').width() * <?php echo $img_dimensions . "\n"; ?>

          const vimPlayer = $('div#vim-player-<?php echo esc_attr($id); ?>')

          vimPlayer.height(h).css('min-height', h + 'px')

          $('a[rel=<?php echo esc_attr($id); ?>]').height(h).css('min-height', h + 'px')

        }
        resize()
        $(window).on('resize', resize)
      })
    }
    init()
  })()
  </script>
<?php
}

if(get_field('play_inline')) { ?>
  <?php if($is_vimeo) { ?>
  <div class="entire-video-container">
  <?php } ?>
  <div id="<?php echo esc_attr($id); ?>" class="<?php echo esc_attr($class_name); ?>">
    <a rel="<?php echo esc_attr($id); ?>" class="ibf-video-card-image-container" href="<?php echo $link; ?>"
    style="<?php
    if ($img) {
      echo 'background-image: url(' . $img . ');';
    }
    ?>
    background-size: cover; background-position: <?php echo $img_layout; ?>">
      <div class="play-icon-container">
        <?php if ($svg_play_icon) { ?>
          <img class="svg-play-icon" src="<?php echo $svg_play_icon; ?>">
        <?php } elseif (!empty($svg_code)) { ?>
          <div class="svg-play-icon">
            <?php echo $svg_code; ?>
          </div>
        <?php } else { ?>
          <span class="play-icon" aria-hidden="true"></span>
        <?php } ?>
      </div>
    </a>
    <?php if(!empty($label)) { ?>
      <div class="ibf-video-label-container">
        <a href="<?php echo $link; ?>" class="ibf-video-card-label">
          <?php echo esc_attr($label); ?> &raquo;
        </a>
      </div>
    <?php } ?>
  </div>
  <?php if($is_vimeo) {
    wp_enqueue_script('init-inline-vimeo-embed');
    ?>
    <div id="vim-player-<?php echo esc_attr($id); ?>" class="inline-vimeo-player"></div>
  </div>
    <script type="text/javascript">
      (function() {
        let elem = document.querySelector('a[rel=<?php echo esc_attr($id); ?>]')
        let thisPlayerDiv = document.querySelector('div#vim-player-<?php echo esc_attr($id); ?>')
        let divOverlay = document.querySelector('div#<?php echo esc_attr($id); ?>')
        let videoUrl = '<?php echo $vimeo_embed_url; ?>'
        // console.log('vimeo url = ', videoUrl)
        elem.addEventListener('click', function(e) {
          e.preventDefault()
          // console.log('in click event, event target =', e.target.id)
          create_vim_api_elements(thisPlayerDiv.id, thisPlayerDiv.offsetWidth, thisPlayerDiv.offsetHeight, videoUrl)
          divOverlay.addEventListener("transitionend", endTransition)
          divOverlay.classList.add("removed")
        })

        function endTransition() {
          // console.log('in end transition function')
          // thisPlayerDiv.classList.remove("removed")
          waitForVimeo()
          divOverlay.removeEventListener("transitionend", endTransition)
        }
      })()
    </script>
  <?php } else {
    wp_enqueue_script('init-inline-youtube-embed');
    ?>
  <script type="text/javascript">
    (function() {
      let elem = document.querySelector('a[rel=<?php echo esc_attr($id); ?>]')
      let thisPlayerDiv = document.querySelector('div#<?php echo esc_attr($id); ?>')
      let videoId = '<?php echo $video_id; ?>'

      elem.addEventListener('click', function(e) {
        e.preventDefault()
        // console.log('in click event, event target =', thisPlayerDiv.id)
        thisPlayerDiv.addEventListener("transitionend", endTransition)
        thisPlayerDiv.classList.add("removed")
        // create_yt_api_elements(thisPlayerDiv.id, thisPlayerDiv.offsetWidth, thisPlayerDiv.offsetHeight, videoId)
      })

      function endTransition() {
        // console.log('in end transition function')
        create_yt_api_elements(thisPlayerDiv.id, thisPlayerDiv.offsetWidth, thisPlayerDiv.offsetHeight, videoId)
        // thisPlayerDiv.classList.remove("removed")
        thisPlayerDiv.removeEventListener("transitionend", endTransition)
      }
    })()
  </script>
  <?php
  }
} else {
  if (!wp_script_is('lity-modal')) {
    wp_enqueue_script('lity-modal');
  }
  if(!get_field('featured_video_with_styles')) { ?>
  <div id="<?php echo esc_attr($id); ?>" class="<?php echo esc_attr($class_name); ?>">
  <a rel="<?php echo esc_attr($id); ?>" <?php echo $lity_popup_text; ?> class="ibf-video-card-image-container" href="<?php echo $link; ?>"
    style="<?php
    if ($img) {
      echo 'background-image: url(' . $img . ');';
    }
    ?>
    background-size: cover; background-position: <?php echo $img_layout; ?>">
      <div class="play-icon-container">
        <?php if ($svg_play_icon) { ?>
          <img class="svg-play-icon" src="<?php echo $svg_play_icon; ?>">
        <?php } elseif (!empty($svg_code)) { ?>
          <div class="svg-play-icon">
            <?php echo $svg_code; ?>
          </div>
        <?php } else { ?>
          <span class="play-icon" aria-hidden="true"></span>
        <?php } ?>
      </div>
    </a>
    <?php if(!empty($label)) { ?>
      <div class="ibf-video-label-container">
        <a <?php echo $lity_popup_text; ?> href="<?php echo $link; ?>" class="ibf-video-card-label">
          <?php echo esc_attr($label); ?> &raquo;
        </a>
      </div>
    <?php } ?>
  </div>
  <?php } else { ?>
    <div class="wp-block-group ibf-video-card-group">
      <div id="<?php echo esc_attr($id); ?>" class="<?php echo esc_attr($class_name); ?>">
        <a rel="<?php echo esc_attr($id); ?>" <?php echo $lity_popup_text; ?> class="ibf-video-card-image-container" href="<?php echo $link; ?>"
        style="<?php
        if ($img) {
          echo 'background-image: url(' . $img . ');';
        }
        ?>
        background-size: cover; background-position: <?php echo $img_layout; ?>">
          <?php if ($svg_play_icon) { ?>
            <img class="svg-play-icon" src="<?php echo $svg_play_icon; ?>">
          <?php } elseif (!empty($svg_code)) { ?>
            <div class="svg-play-icon">
              <?php echo $svg_code; ?>
            </div>
          <?php } else { ?>
            <span class="play-icon" aria-hidden="true"></span>
          <?php } ?>
        </a>
      <?php if(!empty($label)) { ?>
        <div class="ibf-video-label-container">
          <a <?php echo $lity_popup_text; ?> href="<?php echo $link; ?>" class="ibf-video-card-label">
            <?php echo esc_attr($label); ?> &raquo;
          </a>
        </div>
      <?php } ?>
      </div>
    </div>
  <?php }
} ?>

<style>
  .lity {
    z-index: 100000 !important;
  }

  .lity-wrap {
    z-index: 100001 !important;
  }

  .lity-container {
    z-index: 100002 !important;
  }

  .lity-content {
    z-index: 100003 !important;
  }

  button.lity-close {
    z-index: 100004 !important;

  }
</style>

<?php if (get_field('featured_video_with_styles')) { ?>
  <style>
  div.wp-block-group.ibf-video-card-group {
    background: url("<?php echo $dots_background_img; ?>") no-repeat;
    background-size: contain;
    margin: -180px auto 0 auto;
    position: relative;
    z-index: 2;
  }

  div.wp-block-group.ibf-video-card-group .ibf-video-card {
    position: relative;
    width: 90%;
    top: -40px;
    margin: 0 auto 0 auto;
  }

  @media screen and (max-width: 1200px) {
    div.wp-block-group.ibf-video-card-group {
      margin-top: -100px;
    }
  }
  </style>
<?php }
if (!$disabled) {
  if (!$svg_play_icon && empty($svg_code)) { ?>
    <style>
      a.ibf-video-card-image-container .play-icon {
        border:5px solid #FFF;
        -webkit-border-radius: 50%;
        -moz-border-radius:  50%;
        border-radius:  50%;
        color:#FFF;
        position:absolute !important;
        will-change:color, border-color;
        -webkit-transition: color 0.5s, border-color 0.5s;
        -moz-transition: color 0.5s, border-color 0.5s;
        transition: color 0.5s, border-color 0.5s;
      }
      a.ibf-video-card-image-container .play-icon:after {
        content: '';
        display: block;
        border: 0;
        background: transparent;
        box-sizing: border-box;
        width: 0;
        height: 55px;
        border-color: transparent transparent transparent #fff;
        transition: 100ms all ease;
        cursor: pointer;
        border-style: solid;
        border-width: 30px 0 30px 50px;
        margin: 15px 0 0 28px;
        -webkit-transition: color 0.5s, border-color 0.5s;
        -moz-transition: color 0.5s, border-color 0.5s;
        transition: color 0.5s, border-color 0.5s;
      }

      a.ibf-video-card-image-container .play-icon {
        left: 0;
        top: 0;
        width: 100px;
        height: 100px;
        bottom: 0;
        right: 0;
        margin: auto;
      }
    </style>
  <?php } else { ?>
    <style>
      a.ibf-video-card-image-container .svg-play-icon {
        position: absolute;
        left: 0;
        top: 0;
        width: 100px;
        height: 100px;
        bottom: 0;
        right: 0;
        margin: auto;
      }
      a.ibf-video-card-image-container .svg-play-icon svg ellipse {
        transition: fill 0.2s ease-in;
        fill: #5b5b5b;
      }
      a.ibf-video-card-image-container:hover svg ellipse {
        fill: #000000;
      }
    </style>
  <?php }
} else { ?>
  <style>
    .ibf-video-card a.ibf-video-card-image-container {
      filter: grayscale(1);
      pointer-events: none;
    }
    a.ibf-video-card-image-container .svg-play-icon {
      position: absolute;
      left: 0;
      top: 0;
      width: 100px;
      height: 100px;
      bottom: 0;
      right: 0;
      margin: auto;
      filter: grayscale(1);
    }
    a.ibf-video-card-image-container .svg-play-icon svg ellipse {
      transition: fill 0.2s ease-in;
      fill: #5b5b5b;
    }
    a.ibf-video-card-image-container:hover svg ellipse {
      fill: #000000;
    }
  </style>
<?php } ?>
