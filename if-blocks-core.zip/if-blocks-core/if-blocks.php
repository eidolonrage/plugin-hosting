<?php

/*
 * Plugin Name: IF Blocks Core
 * Description: A set of reusable WordPress blocks. Requires Advanced Custom Fields Pro.
 * Author: Inbound Found
 * Version: 1.5.7
 * Primary Branch: main
 * Text Domain: if-blocks
 */

namespace ibfblocks;

use function ibfblocks\includes\logit;

/* Constants */

// base if-blocks directory url with trailing slash
define( 'IF_BLOCKS_PLUGIN_URL', plugin_dir_url( __FILE__ ));

// base if-blocks directory path with trailing slash
define( 'IF_BLOCKS_PLUGIN_PATH', wp_normalize_path(plugin_dir_path( __FILE__ )));

define('IF_BLOCKS_PLUGIN_SLUG', plugin_basename(__DIR__));
define('IF_BLOCKS_PLUGIN_NAME', plugin_basename(__FILE__));


if (!defined('ABSPATH')) { exit; }

/* only allow plugin activation if ACF Pro is installed and activated */
add_action('plugins_loaded', function() {
  // Check that ACF is activated
  if (!function_exists('acf_register_block_type')) {
    _e('Advanced Custom Fields Pro must be installed and activated prior to using the IF Blocks plugin. Plugin will be deactivated.', 'if-blocks');
    deactivate_plugins(plugin_basename(__FILE__));
  }
});

// Set ACF JSON AutoSync Save/Load directories
add_filter('acf/settings/load_json', function($paths) {
  unset($paths[0]);
  $paths[] = IF_BLOCKS_PLUGIN_PATH . 'acf-json';
  return $paths;
});
add_filter('acf/settings/save_json', function($path) {
  return IF_BLOCKS_PLUGIN_PATH . 'acf-json';
});

require_once(__DIR__ . '/includes/register.php');
require_once(__DIR__ . '/includes/functions.php');
require_once(__DIR__ . '/includes/if-shortcodes.php');
require_once(__DIR__ . '/includes/adminpage.php');

/* uncomment this below to display the code for a post template on the front end */
if (file_exists(__DIR__ . '/includes/post-template-helper.php')) {
	require_once(__DIR__ . '/includes/post-template-helper.php');
}

if (file_exists(__DIR__ . '/includes/updates/class-if-blocks-core-updates.php')) {
	require_once(__DIR__ . '/includes/updates/class-if-blocks-core-updates.php');
}

/**
 * Facet Cards Register Facets
 */
if( class_exists( 'FacetWP' ) ) {
	if (file_exists(__DIR__ . '/blocks/facet-cards/register-facets.php')) {
		require_once(__DIR__ . '/blocks/facet-cards/register-facets.php');
	}
}

/* Setup IF Blocks Options Page with initial fields */
if (file_exists(__DIR__ . '/includes/if-blocks-options.php')) {
  require_once(__DIR__ . '/includes/if-blocks-options.php');
}

/* Requires for individual blocks */
// Accordion
if (file_exists(__DIR__ . '/blocks/accordion/class-block.php')) {
  require_once(__DIR__ . '/blocks/accordion/class-block.php');
}

// Facet Cards
if (file_exists(__DIR__ . '/blocks/facet-cards/class-block.php')) {
	require_once(__DIR__ . '/blocks/facet-cards/class-block.php');
}

// Linkable Image
if (file_exists(__DIR__ . '/blocks/linkable-image/class-block.php')) {
  require_once(__DIR__ . '/blocks/linkable-image/class-block.php');
}

// Masonry Gallery
if (file_exists(__DIR__ . '/blocks/masonry-gallery/class-block.php')) {
	require_once(__DIR__ . '/blocks/masonry-gallery/class-block.php');
}
/*
// Modal Content
if (file_exists(__DIR__ . '/blocks/modal-content/class-block.php')) {
	require_once(__DIR__ . '/blocks/modal-content/class-block.php');
}
*/
// On Page Subnav Menu
if (file_exists(__DIR__ . '/blocks/on-page-subnav/class-block.php')) {
  require_once(__DIR__ . '/blocks/on-page-subnav/class-block.php');
}

// Static Cards
if (file_exists(__DIR__ . '/blocks/static-cards/class-block.php')) {
  require_once(__DIR__ . '/blocks/static-cards/class-block.php');
}
/* Initialize Static Cards templates */
if (file_exists(__DIR__ . '/includes/init-static-cards-templates.php')) {
	require_once(__DIR__ . '/includes/init-static-cards-templates.php');
}

// Video Card
if (file_exists(__DIR__ . '/blocks/video-card/class-block.php')) {
	require_once(__DIR__ . '/blocks/video-card/class-block.php');
}
