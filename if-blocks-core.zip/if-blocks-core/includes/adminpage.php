<?php

use function \ibfblocks\includes\logit;
use function \ibfblocks\includes\get_substring_between_words;

/* Create the If Blocks Settings Page options page and enqueue necessary assets */
function plugin_admin_add_page() {
  add_options_page('IF Blocks Reports Page', 'IF Blocks Reports', 'manage_options', 'if-blocks-reporting', 'if_blocks_settings_page'); //settings menu page
}
add_action('admin_menu', 'plugin_admin_add_page');

function enqueue_if_admin_page_styles() {
  if(!wp_style_is('if-admin-page-styles')) {
    wp_enqueue_style('if-admin-page-styles', IF_BLOCKS_PLUGIN_URL . 'styles/admin-page-styles.css', array(), time());
  }
}
add_action('admin_enqueue_scripts', 'enqueue_if_admin_page_styles');

/**
 * create the IF Blocks Settings and Options page
 **/
function if_blocks_settings_page() {
	//HTML and PHP for Plugin Admin Page
	$language = apply_filters( 'wpml_current_language', null );;
  if($language) {
		switch ($language) {
        case "en":
          $language = "English";
          break;
          
        case "fr":
          $language = "French";
          break;
          
        case "fr-ca":
          $language = "French (Canadian)";
          break;
          
        default:
          $language = "";
          break;
    }
	}
	?>
    <p>Now an even more recent version arrives.</p>
  <h1 class="settings-page-title"><?php _e('IF Blocks Reporting Options', 'if-blocks'); ?></h1>
  <?php if(!empty($language)) { ?>
    <h3 class="current-language-setting"><?php _e('WPML current language: ' . $language, 'if-blocks'); ?></h3>
  <?php } ?>
  <div class="settings-page-columns">
    <div class="settings-page-column">
      <button class="if-blocks-report-button" id="inline-report-button"><?php _e('Generate if-blocks usage report', 'if-blocks'); ?></button>
    </div>
    <div class="settings-page-column">
      <button class="if-blocks-report-button" id="reports-cleanup-button"><?php _e('Delete old usage report CSVs', 'if-blocks'); ?></button>
    </div>
  </div>
  <div class="loading-image-container">
    <img id="if-loading-wheel-image" src="<?php echo IF_BLOCKS_PLUGIN_URL . '/assets/images/loading.gif'; ?>" alt="<?php _e('loading wheel animated gif', 'if-blocks'); ?>" width="100" height="100">
  </div>
  <div id="reports-directory-cleaned-message"></div>
  <div id="if-blocks-report-area"></div>

  <script>
    var if_blocks_ajaxurl = "<?php echo site_url() . '/wp-admin/admin-ajax.php'; ?>";

    jQuery(document).ready(function() {

      jQuery('#inline-report-button').on('click', function(a) {
        a.preventDefault();
        let load_wheel = document.querySelector('#if-loading-wheel-image')
        let report_message = document.querySelector('#reports-directory-cleaned-message')
        if(report_message) {
          report_message.style.display = "none"
        }
        /*
        console.log(load_wheel)
        console.dir(load_wheel)
        */
        load_wheel.style.display = "block"
        jQuery.post(
          if_blocks_ajaxurl,
          {
            'action': 'ifblocks_report'
          },
          function(response) {
            load_wheel.style.display = "none"
            document.querySelector('#if-blocks-report-area').innerHTML = response
          },
          "html"
        );
      });
      
      jQuery('#reports-cleanup-button').on('click', function(a) {
        a.preventDefault();
        let load_wheel = document.querySelector('#if-loading-wheel-image')
        /*
        console.log(load_wheel)
        console.dir(load_wheel)
        */
        load_wheel.style.display = "block"
        jQuery.post(
          if_blocks_ajaxurl,
          {
            'action': 'clean_reports_directory'
          },
          function(response) {
            load_wheel.style.display = "none"
            let reports_message = document.querySelector('#reports-directory-cleaned-message')
            reports_message.innerHTML = response
            reports_message.style.display = "block"
            let dl_button = document.querySelector('.blocks-report-download-link')
            if(dl_button) {
              dl_button.style.display = "none"
            }
          },
          "html"
        );
      });
    });
  </script>
<?php }

/**
 * Generate a report of all IF Blocks being used on all posts, including CPTs
 * and display it inline as a table, as well as generating a downloadable CSV
 **/
function ifblocks_report() {
  $args = array(
    'post_type'         => array('any'),
    'posts_per_page'    => -1,
    'orderby'           => 'type',
    'order'             => 'ASC',
    'fields'            => 'ids',
    'suppress_filters'  => false
  );
  
  // query posts and pages to find locations of if-blocks
  
  $all_posts = get_posts($args);
  
  if ( !empty($all_posts) ) {
    
    $urlparts = wp_parse_url(home_url());
    $domain = str_replace(array('.com', '.'), '_', $urlparts['host']);
    
    $csv_rows = array();
    
    foreach($all_posts as $post) {
      $post_content = get_the_content('', false, $post);
      $post_lang_deets = apply_filters( 'wpml_post_language_details', null, $post );
      $post_lang = $post_lang_deets['display_name'];
      
      if(!$post_lang) {
        $post_lang = "N/A";
      }
      if(str_contains($post_content, '<!-- wp:ibf/') || str_contains($post_content, '<!-- wp:acf/ibf') || str_contains($post_content, '<!-- wp:if-')) {
        /*
        if($post == $all_posts[0]) {
          logit('in ifblocks_report_csv, $post_content =', get_the_content('', false, $post));
        }
        */
        
        $blocks_array = explode('<!-- wp:', $post_content);
        $all_blocks = array();
        foreach($blocks_array as $string) {
          $block = '';
          if(str_contains($string, 'ibf/')) {
            $block = get_substring_between_words($string, 'ibf/', ' {');
          } elseif(str_contains($string, 'acf/ibf')) {
            $block = get_substring_between_words($string, 'acf/ibf', ' {');
          } elseif(str_contains($string, 'if-dynamic-blocks')) {
            $block = substr($string, strpos($string, '/') + 1, strpos($string, ' ') - strpos($string, '/') - 1);
          }
          if(!empty($block)) {
            $all_blocks[] = rtrim($block);
          }
        }
        $all_blocks = array_unique($all_blocks);
        $csv_rows[] = [ get_the_title( $post ), get_post_type( $post ), $post_lang, get_the_permalink( $post ), implode(' | ', $all_blocks)];
      }
    }
    
    if(!empty($csv_rows) && is_array($csv_rows)) {
	    $filename = 'if_blocks_usage_report_' . $domain . date('Y-m-d-g-i-a') . '.csv';
	    $filepath = IF_BLOCKS_PLUGIN_PATH . 'reports/' . $filename;
	    $fileurl = IF_BLOCKS_PLUGIN_URL . 'reports/' . $filename;
      ?>
      <div class="if-blocks-download-area">
        <a href="<?php echo $fileurl; ?>" class="blocks-report-download-link"><?php _e('Download Report as CSV', 'if-blocks'); ?></a>
      </div>
      <div class="if-report-container">
        <table class="if-blocks-report-table">
          <tr class="if-blocks-report-header-row">
            <th>Page/Post Title - Linked</th>
            <th>Post Type</th>
            <th>Post Language</th>
            <th>Blocks in Use</th>
          </tr>
        <?php
        foreach($csv_rows as $row) { ?>
          <tr>
            <td><a href="<?php echo $row[3]; ?>"><?php echo $row[0]; ?></a></td>
            <td class="post-type-column"><?php echo $row[1]; ?></td>
            <td class="post-language-column"><?php echo $row[2]; ?></td>
            <td><?php echo $row[4]; ?></td>
          </tr>
        <?php } ?>
        </table>
      </div>
    <?php
      array_unshift($csv_rows, array("Post Title", "Post Type", "Post Language", "Permalink", "Blocks in Use"));
	    $f = fopen($filepath, 'w');
	    
	    if ($f === false) {
		    wp_die('Error opening the file ' . $filepath);
	    }
	    
	    // write each row at a time to a file
	    foreach ($csv_rows as $row) {
		    fputcsv($f, $row);
	    }
	    
	    // close the file
	    fclose($f);
	    // logit('in ifblocks_report_csv, $fileurl =', $fileurl);
     
    } else {
    // no posts or pages found
    echo 'Could not find posts or pages with custom IF blocks.';
    }
  } else {
    // no posts or pages found
    echo 'Could not find posts or pages...';
  }

  // stop execution
  wp_die();
}
add_action( 'wp_ajax_ifblocks_report', 'ifblocks_report' );

function clean_reports_directory() {
	$files = glob(IF_BLOCKS_PLUGIN_PATH . 'reports/*'); // get all file names
    // logit('in clean_reports_directory, $files=', $files);
	foreach($files as $file){ // iterate files
		if(is_file($file)) {
			unlink($file); // delete file
		}
	}
  ?>
    <p style="text-align: center;"><?php _e('All CSV report files have been deleted.'); ?></p>
<?php
  die;
}
add_action( 'wp_ajax_clean_reports_directory', 'clean_reports_directory' );
