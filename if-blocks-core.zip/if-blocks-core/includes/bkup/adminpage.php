<?php

use function \ibfblocks\includes\logit;
use function \ibfblocks\includes\get_substring_between_words;

/* Create the If Blocks Settings Page options page and enqueue necessary assets */
function plugin_admin_add_page() {
  add_options_page('IF Blocks Settings Page', 'IF Blocks Settings', 'manage_options', 'page_slug', 'if_blocks_settings_page'); //settings menu page
}
add_action('admin_menu', 'plugin_admin_add_page');

function enqueue_if_admin_page_styles() {
  if(!wp_style_is('if-admin-page-styles')) {
    wp_enqueue_style('if-admin-page-styles', IF_BLOCKS_PLUGIN_URL . 'styles/admin-page-styles.css', array(), time());
  }
}
add_action('admin_enqueue_scripts', 'enqueue_if_admin_page_styles');

/**
 * Generate a report of all IF Blocks being used on all posts, including CPTs
 * and display it inline as a table
 **/
function ifblocks_report() {
  $args = array(
    'post_type'       => array('any'),
    'posts_per_page'  => -1,
    'orderby'         => 'type',
    'order'           => 'ASC',
    'fields'          => 'ids'
  );
  
  // query posts and pages to find locations of if-blocks
  
  $all_posts = get_posts($args);
  
  if ( !empty($all_posts) ) {
    
    $urlparts = wp_parse_url(home_url());
    $domain = str_replace(array('.com', '.'), '_', $urlparts['host']);
    
    $csv_rows = array();
    
    foreach($all_posts as $post) {
      $post_content = get_the_content('', false, $post);
      if(str_contains($post_content, '<!-- wp:ibf/') || str_contains($post_content, '<!-- wp:acf/ibf') || str_contains($post_content, '<!-- wp:if-')) {
        /*
        if($post == $all_posts[0]) {
          logit('in ifblocks_report_csv, $post_content =', get_the_content('', false, $post));
        }
        */
        
        $blocks_array = explode('<!-- wp:', $post_content);
        $all_blocks = array();
        foreach($blocks_array as $string) {
          $block = '';
          if(str_contains($string, 'ibf/')) {
            $block = get_substring_between_words($string, 'ibf/', ' {');
          } elseif(str_contains($string, 'acf/ibf')) {
            $block = get_substring_between_words($string, 'acf/ibf', ' {');
          } elseif(str_contains($string, 'if-dynamic-blocks')) {
            $block = substr($string, strpos($string, '/') + 1, strpos($string, ' ') - strpos($string, '/') - 1);
          }
          if(!empty($block)) {
            $all_blocks[] = rtrim($block);
          }
        }
        $all_blocks = array_unique($all_blocks);
        $csv_rows[] = [ get_the_title( $post ), get_post_type( $post ), get_the_permalink( $post ), implode(' | ', $all_blocks)];
      }
    }
    
    if(!empty($csv_rows) && is_array($csv_rows)) {
      ?>
      <div class="if-report-container">
        <table class="if-blocks-report-table">
          <tr class="if-blocks-report-header-row">
            <th>Page/Post Title - Linked</th>
            <th>Post Type</th>
            <th>Blocks in Use</th>
          </tr>
        <?php
        foreach($csv_rows as $row) { ?>
          <tr>
            <td><a href="<?php echo $row[2]; ?>"><?php echo $row[0]; ?></a></td>
            <td class="post-type-column"><?php echo $row[1]; ?></td>
            <td><?php echo $row[3]; ?></td>
          </tr>
        <?php } ?>
        </table>
      </div>
    <?php
    } else {
    // no posts or pages found
    echo 'Could not find posts or pages with custom IF blocks.';
    }
  } else {
    // no posts or pages found
    echo 'Could not find posts or pages...';
  }

  // stop execution
  wp_die();
}
add_action( 'wp_ajax_ifblocks_report', 'ifblocks_report' );


/**
 * Generate a CSV report of all IF Blocks being used on all posts, including CPTs
 **/
function ifblocks_report_csv() {
    $args = array(
	      'post_type'       => array('any'),
        'posts_per_page'  => -1,
        'orderby'         => 'type',
        'fields'          => 'ids'
    );

    // query posts and pages to find locations of if-blocks
	  
    $all_posts = get_posts($args);
    
    if ( !empty($all_posts) ) {

	      $urlparts = wp_parse_url(home_url());
	      $domain = str_replace(array('.com', '.'), '_', $urlparts['host']);

        $csv_rows = array();
        $csv_rows[] = ["Post Title", "Post Type", "Permalink", "Blocks in Use"];

        foreach($all_posts as $post) {
	          $post_content = get_the_content('', false, $post);
            if(str_contains($post_content, '<!-- wp:ibf/') || str_contains($post_content, '<!-- wp:acf/ibf') || str_contains($post_content, '<!-- wp:if-')) {
              /*
              if($post == $all_posts[0]) {
                  logit('in ifblocks_report_csv, $post_content =', get_the_content('', false, $post));
              }
              */
              $blocks_array = explode('<!-- wp:', $post_content);
              $all_blocks = array();
              foreach($blocks_array as $string) {
                  $block = '';
                  if(str_contains($string, 'ibf/')) {
                      $block = get_substring_between_words($string, 'ibf/', ' {');
                  } elseif(str_contains($string, 'acf/ibf')) {
                      $block = get_substring_between_words($string, 'acf/ibf', ' {');
                  } elseif(str_contains($string, 'if-dynamic-blocks')) {
                      $block = substr($string, strpos($string, '/') + 1, strpos($string, ' ') - strpos($string, '/') - 1);
                  }
                  if(!empty($block)) {
                      $all_blocks[] = rtrim($block);
                  }
              }
              $all_blocks = array_unique($all_blocks);
              $csv_rows[] = [ get_the_title( $post ), get_post_type( $post ), get_the_permalink( $post ), implode(' | ', $all_blocks)];
            }
        }

        if(!empty($csv_rows) && is_array($csv_rows)) {
            // logit( 'in ifblocks_report_csv, $csv_rows =', $csv_rows );

            $filename = 'if_blocks_usage_report_' . $domain . date('Y-m-d-g-i-a') . '.csv';
            $filepath = IF_BLOCKS_PLUGIN_PATH . 'reports/' . $filename;

            $fileurl = IF_BLOCKS_PLUGIN_URL . 'reports/' . $filename;

            $f = fopen($filepath, 'w');

            if ($f === false) {
                wp_die('Error opening the file ' . $filepath);
            }

            // write each row at a time to a file
            foreach ($csv_rows as $row) {
                fputcsv($f, $row);
            }

            // close the file
            fclose($f);
            // logit('in ifblocks_report_csv, $fileurl =', $fileurl);

            echo $fileurl;
            die;
        }
    }
}
add_action( 'wp_ajax_ifblocks_report_csv', 'ifblocks_report_csv' );

/**
 * create the IF Blocks Settings and Options page
 **/
function if_blocks_settings_page() {
  //HTML and PHP for Plugin Admin Page
  ?>
  <h1 class="settings-page-title">IF Blocks Settings and Options</h1>
  <div class="settings-page-columns">
    <div class="settings-page-column">
      <button class="if-blocks-report-button" id="inline-report-button">Generate if-blocks usage report inline</button>
    </div>
    <div class="settings-page-column">
      <button class="if-blocks-report-button" id="csv-report-button">Download report as CSV</button>
    </div>
  </div>
  <div class="loading-image-container">
    <img id="if-loading-wheel-image" src="<?php echo IF_BLOCKS_PLUGIN_URL . '/assets/images/loading.gif'; ?>" alt="<?php _e('loading wheel animated gif', 'ibfblocks'); ?>" width="100" height="100">
  </div>
  <div id="if-blocks-report-area"></div>

  <script>
    var if_blocks_ajaxurl = "<?php echo site_url() . '/wp-admin/admin-ajax.php'; ?>";

    jQuery(document).ready(function() {

      jQuery('#inline-report-button').on('click', function(a) {
        a.preventDefault();
        let load_wheel = document.querySelector('#if-loading-wheel-image')
        /*
        console.log(load_wheel)
        console.dir(load_wheel)
        */
        load_wheel.style.display = "block"
        jQuery.post(
          if_blocks_ajaxurl,
          {
            'action': 'ifblocks_report'
          },
          function(response) {
            load_wheel.style.display = "none"
            document.querySelector('#if-blocks-report-area').innerHTML = response
          },
          "html"
        );
      });

      jQuery('#csv-report-button').on('click', function(a) {
        a.preventDefault();
        let load_wheel = document.querySelector('#if-loading-wheel-image')
        /*
        console.log(load_wheel)
        console.dir(load_wheel)
        */
        load_wheel.style.display = "block"
        jQuery.post(
          if_blocks_ajaxurl,
          {
            'action': 'ifblocks_report_csv'
          },
          function(response) {
            console.log(response)
            load_wheel.style.display = "none"
            document.querySelector('#if-blocks-report-area').innerHTML = '<a href="' + response + '" class="blocks-report-download-link">Download Report</a>'
            // jQuery('#if-blocks-report-area').html(response);
          },
          "text"
        );
      });
    });
  </script>
<?php } ?>

