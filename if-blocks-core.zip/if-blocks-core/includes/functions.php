<?php

/*
 * Utility functions for if-blocks.
 */

namespace ibfblocks\includes;

if (!defined('ABSPATH')) { exit; }

function logit() {
  $args = func_get_args();
  if (empty($args)) { return; }
  $stuffToLog = '';
  foreach ($args as $arg) {
    if (!is_string($arg)) {
      $arg = print_r($arg, true);
    }
    $stuffToLog .= $arg . ' ';
  }

  $log_path = __DIR__ . '/log.txt';
  if (file_exists($log_path) && filesize($log_path) > 5000000) {
    $f = fopen($log_path, 'w');
  } else {
    $f = fopen($log_path, 'a+');
  }
  fwrite($f, $stuffToLog . "\n");
  fclose($f);
}

function get_substring_between_words($str, $starting_word, $ending_word)
{
  $substring_start = strpos($str, $starting_word);
  //Adding the starting index of the starting word to
  //its length would give its ending index
  $substring_start += strlen($starting_word);
  //Length of our required sub string
  $size = strpos($str, $ending_word, $substring_start) - $substring_start;
  // Return the substring from the index substring_start of length size
  return substr($str, $substring_start, $size);
}

function get_substring_between_index_and_string ($str, $index, $ending_string) {
  $start = $index;
  $end = strpos($str, $ending_string);
  return substr($str, $start, $end);
}

// Use this to look at block default settings in console log
/*
if (file_exists(IF_BLOCKS_PLUGIN_PATH . 'scripts/check_block_defaults.js')) {
  add_action('enqueue_block_editor_assets', function () {
    $js_file = 'check_block_defaults.js';

    // Enqueue block editor JS
    wp_enqueue_script(
      'check-block-defaults',
      plugins_url($js_file, __FILE__),
      array('wp-blocks', 'wp-hooks'),
      filemtime(plugin_dir_path(__FILE__) . $js_file),
      true
    );
  });
}
*/
logit('now we are cooking with gas');
