<?php

namespace ibfblocks;

use function ibfblocks\includes\logit;

if(!defined('ABSPATH')) { exit; }

if (!class_exists(__NAMESPACE__ . '\IbfOptionsPage')) {

  class IbfOptionsPage {
    function __construct() {
      add_action('acf/init', array($this, 'addOptionsPage'));
      // logit('in options page contruct function');
    }

    function addOptionsPage() {
      if(function_exists('acf_add_options_page')) {
        // logit('adding options page');
        acf_add_options_page(array(
          'page_title' => 'IF Blocks Options',
          'menu_title' => 'IF Blocks Options',
          'menu_slug' => 'if-blocks-options',
          'capability' => 'administrator',
          'position' => '77.5',
          'redirect' => false
        ));

        acf_add_local_field_group(array(
          'key' => 'group_632368164c4a9',
          'title' => 'IF Cards Options',
          'fields' => array(
            array(
              'key' => 'field_6323684ae5d85',
              'label' => 'Gradient Overlay Color Choices',
              'name' => 'gradient_overlay_color_choices',
              'type' => 'repeater',
              'instructions' => '',
              'required' => 0,
              'conditional_logic' => 0,
              'wrapper' => array(
                'width' => '',
                'class' => '',
                'id' => '',
              ),
              'acfe_repeater_stylised_button' => 0,
              'collapsed' => '',
              'min' => 0,
              'max' => 5,
              'layout' => 'table',
              'button_label' => '',
              'sub_fields' => array(
                array(
                  'key' => 'field_632368e5e5d86',
                  'label' => 'Color',
                  'name' => 'color',
                  'type' => 'text',
                  'instructions' => '',
                  'required' => 0,
                  'conditional_logic' => 0,
                  'wrapper' => array(
                    'width' => '',
                    'class' => '',
                    'id' => '',
                  ),
                  'default_value' => '',
                  'placeholder' => '',
                  'prepend' => '',
                  'append' => '',
                  'maxlength' => '',
                ),
                array(
                  'key' => 'field_63236a23f9301',
                  'label' => 'Custom Class',
                  'name' => 'custom_class',
                  'type' => 'text',
                  'instructions' => '',
                  'required' => 0,
                  'conditional_logic' => 0,
                  'wrapper' => array(
                    'width' => '',
                    'class' => '',
                    'id' => '',
                  ),
                  'default_value' => '',
                  'placeholder' => '',
                  'prepend' => '',
                  'append' => '',
                  'maxlength' => '',
                ),
              ),
            ),
            array(
              'key' => 'field_6323754d9434c',
              'label' => 'Default Card Background Image',
              'name' => 'default_bg_img',
              'type' => 'image',
              'instructions' => '',
              'required' => 0,
              'conditional_logic' => 0,
              'wrapper' => array(
                'width' => '',
                'class' => '',
                'id' => '',
              ),
              'uploader' => '',
              'acfe_thumbnail' => 0,
              'return_format' => 'url',
              'preview_size' => 'medium',
              'min_width' => '',
              'min_height' => '',
              'min_size' => '',
              'max_width' => '',
              'max_height' => '',
              'max_size' => '',
              'mime_types' => '',
              'library' => 'all',
            ),
            array(
              'key' => 'field_632380d873e17',
              'label' => 'Default Card Icon',
              'name' => 'default_card_icon',
              'type' => 'image',
              'instructions' => '',
              'required' => 0,
              'conditional_logic' => 0,
              'wrapper' => array(
                'width' => '',
                'class' => '',
                'id' => '',
              ),
              'uploader' => '',
              'acfe_thumbnail' => 0,
              'return_format' => 'url',
              'preview_size' => 'medium',
              'min_width' => '',
              'min_height' => '',
              'min_size' => '',
              'max_width' => '',
              'max_height' => '',
              'max_size' => '',
              'mime_types' => '',
              'library' => 'all',
            ),
          ),
          'location' => array(
            array(
              array(
                'param' => 'options_page',
                'operator' => '==',
                'value' => 'if-blocks-options',
              ),
            ),
          ),
          'menu_order' => 0,
          'position' => 'normal',
          'style' => 'default',
          'label_placement' => 'left',
          'instruction_placement' => 'label',
          'hide_on_screen' => '',
          'active' => true,
          'description' => '',
          'show_in_rest' => 0,
          'acfe_display_title' => '',
          'acfe_autosync' => array(
            0 => 'json',
          ),
          'acfe_form' => 0,
          'acfe_meta' => '',
          'acfe_note' => '',
        ));

        $initial_color_choices = array(
          array(
            'color' => 'linear-gradient(0deg, rgba(30, 30, 30, 0.9), rgba(30, 30, 30, 0.9))',
            'class' => ''),
          array(
            'color' => 'linear-gradient(0deg, rgba(0, 177, 172, 0.9), rgba(0, 177, 172, 0.9))',
            'class' => ''),
          array(
            'color' => 'linear-gradient(0deg, rgba(0, 83, 159, 0.9), rgba(0, 83, 159, 0.9))',
            'class' => ''),
          array(
            'color' => 'linear-gradient(145.97deg, rgba(0, 177, 172, 0.9) 1.26%, rgba(0, 83, 159, 0.9) 98.92%)',
            'class' => ''),
          array(
            'color' => 'linear-gradient(0deg, rgba(255, 255, 255, 0.9), rgba(255, 255, 255, 0.9))',
            'class' => 'light-color-bg')
        );
        if (!have_rows('gradient_overlay_color_choices', 'option')) {
         // logit('adding rows to gradient overlay color choices');
          foreach ($initial_color_choices as $choice) {
            $row = array(
              'color' => $choice['color'],
              'custom_class' => $choice['class']
            );
            add_row('gradient_overlay_color_choices', $row, 'option');
          }
        }
      }
    }
  }
  new IbfOptionsPage();
}
