<?php
// Hide content between start and end shortcode blocks
// Completely removes the content before DOM output, so not the same
// as display: none;
function hide_content( $atts ) {
return '';
}

add_shortcode( 'hidethis', 'hide_content' );


