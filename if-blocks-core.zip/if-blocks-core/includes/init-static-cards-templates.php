<?php

function get_static_cards_templates() {
  if (defined("IF_BLOCKS_PLUGIN_PATH")) {
    function get_template_files() {
      /**
       * Start of get cards templates
       */
      $dir_php = IF_BLOCKS_PLUGIN_PATH . 'blocks/static-cards/templates/template-cards-*.php';
      $files = glob($dir_php, GLOB_BRACE);
      $available_templates = array();
      $saved_templates = array();

      $theme_dir = get_stylesheet_directory() . '/templates/plugins/if-static-cards/template-cards-*.php';
      $theme_files = glob($theme_dir, GLOB_BRACE);

      if (!empty($files)) {
        foreach ($files as $filename) {
          $slug = basename($filename, '.php');
          $content = file_get_contents($filename);
          preg_match_all("/Template Name:(.*)\n/siU", $content, $template_name);
          $template = ($template_name[1][0] ?? '');
          $template = trim($template);
          $saved_templates[$slug] = $filename;
          $available_templates[] = array(
            'id' => $slug,
            'value' => $slug,
            'label' => $template,
          );
        }
      }

      if (!empty($theme_files)) {
        foreach ($theme_files as $filename) {
          $slug = basename($filename, '.php');
          $content = file_get_contents($filename);
          preg_match_all("/Template Name:(.*)\n/siU", $content, $template_name);
          $template = ($template_name[1][0] ?? '');
          $template = trim($template);
          $saved_templates[$slug] = $filename;
          $available_templates[] = array(
            'id' => $slug,
            'value' => $slug,
            'label' => $template,
          );
        }
      }

      update_option('_if_static_cards_templates', $saved_templates);
      // ibfblocks\includes\logit($saved_templates);
      return rest_ensure_response($available_templates);
    }
    // \ibfblocks\includes\logit(get_option('_if_dynamic_cards_templates'));
  }
}
add_action('plugins_loaded', 'get_static_cards_templates');

function populate_static_cards_template_choices($field) {
  $field['choices'] = array();

  $choices = get_template_files()->data;

  if(is_array($choices)) {
    foreach ($choices as $choice) {
      $field['choices'][$choice['id']] = $choice['label'];
    }
  }

  // \ibfblocks\includes\logit($choices);
  return $field;
}
add_filter('acf/load_field/name=cards_template', 'populate_static_cards_template_choices');

