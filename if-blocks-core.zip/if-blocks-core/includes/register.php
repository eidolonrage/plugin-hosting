<?php

class IfbRegisterScripts {
	/**
	 * Autoload method
	 *
	 * @return void
	 */
	public function __construct() {
		add_action( 'wp_enqueue_scripts', array( $this, 'register_scripts' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'register_styles' ) );
	}

	/**
	 * Register Scripts for IF Blocks
	 * @return void
	 */
	public function register_scripts() {
		if( ! wp_script_is( 'if-accordion', 'registered' ) ) {
			wp_enqueue_script('if-accordion', IF_BLOCKS_PLUGIN_URL . 'third-party/accordion/accordion.min.js', array('jquery'),
				filemtime(IF_BLOCKS_PLUGIN_PATH . 'third-party/accordion/accordion.min.js'));
		}
		if ( ! wp_script_is( 'desandro-masonry', 'registered' ) ) {
			wp_register_script( 'desandro-masonry', IF_BLOCKS_PLUGIN_URL . 'third-party/masonry/masonry.pkgd.min.js', array( 'jquery' ), filemtime(IF_BLOCKS_PLUGIN_PATH . 'third-party/masonry/masonry.pkgd.min.js'), true );
		}
		if ( ! wp_script_is( 'flickity', 'registered' ) ) {
			wp_register_script( 'flickity', IF_BLOCKS_PLUGIN_URL . 'third-party/flickity/flickity.pkgd.min.js', array( 'jquery' ), filemtime(IF_BLOCKS_PLUGIN_PATH . 'third-party/flickity/flickity.pkgd.min.js'), true );
		}
		if ( ! wp_script_is( 'slick', 'registered' ) ) {
			wp_register_script( 'slick', IF_BLOCKS_PLUGIN_URL . 'third-party/slick-slider/slick.min.js', array( 'jquery' ), filemtime(IF_BLOCKS_PLUGIN_PATH . 'third-party/slick-slider/slick.min.js'), true );
		}
		if (!wp_script_is('lity-modal', 'registered')) {
			wp_register_script('lity-modal', IF_BLOCKS_PLUGIN_URL . 'third-party/lity/lity.min.js', array('jquery'), filemtime(IF_BLOCKS_PLUGIN_PATH . 'third-party/lity/lity.min.js'), true );
		}
		if ( ! wp_script_is( 'check-block-defaults', 'registered' ) ) {
			wp_register_script( 'check-block-defaults', IF_BLOCKS_PLUGIN_URL . 'scripts/check-block-defaults.js', array('wp-blocks', 'wp-hooks'), time(), true );
		}
	}

	public function register_styles() {
		if( ! wp_style_is( 'flickity', 'registered') ) {
			wp_register_style( 'flickity', IF_BLOCKS_PLUGIN_URL . 'third-party/flickity/flickity.css', array(), filemtime(IF_BLOCKS_PLUGIN_PATH . 'third-party/flickity/flickity.css') );
		}
		if( ! wp_style_is( 'lity-styles', 'registered') ) {
			wp_register_style( 'lity-styles', IF_BLOCKS_PLUGIN_URL . 'third-party/lity/lity.min.css', array(), filemtime(IF_BLOCKS_PLUGIN_PATH . 'third-party/lity/lity.min.css') );
		}
	}
}

new IfbRegisterScripts();
