/**
 * WordPress dependencies
 */

// import { addFilter } from "@wordpress/hooks";

/**
 * Call the filter
 *
 * Filter name: blocks.registerBlockType
 * Unique identifier for our change: check-block-default-settings
 * The nameless function that manipulates the passed data is the third parameter
 */

wp.hooks.addFilter(
  "blocks.registerBlockType",
  "check-block-default-settings",
  (settings, name) => {
    console.log(settings);
    return settings;
  }
);